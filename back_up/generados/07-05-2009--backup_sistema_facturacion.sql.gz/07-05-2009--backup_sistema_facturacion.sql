-- Dump de la Base de Datos
-- Fecha: jueves 07 mayo 2009 - 17:35:47
--
-- BENITEZ CARLOS ALBERTO, cabenitez83@gmail.com
-- Soporte: http://www.cabenitez.com.ar
--
-- Host: `localhost`    Database: `db_ele_2`
-- ------------------------------------------------------
-- Server version	5.0.45-community-nt-log

--
-- Table structure for table `agenda`
--

DROP TABLE IF EXISTS agenda;
CREATE TABLE `agenda` (
  `id` int(11) NOT NULL auto_increment,
  `nombre` char(50) NOT NULL,
  `telefono` char(50) NOT NULL,
  `correo` char(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `agenda`
--

LOCK TABLES agenda WRITE;
INSERT INTO agenda VALUES('1', 'BETO', 'sadasdsa', 'dasdsa@sadsa.com');
INSERT INTO agenda VALUES('2', 'DSAD', 'asdasd', 'asdasd');
INSERT INTO agenda VALUES('3', 'SADASD', 'sadsa', '');
INSERT INTO agenda VALUES('4', 'LUCAS MATIAS DOMINGUEZ', '03752-15548163', 'lmdominguez@dos-insumos.com.ar');
UNLOCK TABLES;


--
-- Table structure for table `ajuste_precio`
--

DROP TABLE IF EXISTS ajuste_precio;
CREATE TABLE `ajuste_precio` (
  `cod_grupo` int(11) NOT NULL,
  `cod_categoria` int(11) NOT NULL,
  `utilidad` float NOT NULL,
  PRIMARY KEY  (`cod_grupo`,`cod_categoria`),
  KEY `Refcategoria135` (`cod_categoria`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ajuste_precio`
--

LOCK TABLES ajuste_precio WRITE;
INSERT INTO ajuste_precio VALUES('2', '2', '30');
INSERT INTO ajuste_precio VALUES('1', '1', '13');
INSERT INTO ajuste_precio VALUES('2', '1', '50');
INSERT INTO ajuste_precio VALUES('11', '3', '30');
INSERT INTO ajuste_precio VALUES('1', '4', '10');
INSERT INTO ajuste_precio VALUES('9', '1', '2');
INSERT INTO ajuste_precio VALUES('9', '2', '1');
INSERT INTO ajuste_precio VALUES('11', '1', '30');
INSERT INTO ajuste_precio VALUES('11', '2', '10');
INSERT INTO ajuste_precio VALUES('1', '2', '30');
INSERT INTO ajuste_precio VALUES('3', '2', '12');
INSERT INTO ajuste_precio VALUES('4', '2', '5');
INSERT INTO ajuste_precio VALUES('5', '2', '45');
UNLOCK TABLES;


--
-- Table structure for table `alicuota_iva`
--

DROP TABLE IF EXISTS alicuota_iva;
CREATE TABLE `alicuota_iva` (
  `cod_iva` int(11) NOT NULL auto_increment,
  `nombre` text NOT NULL,
  `tasa` float NOT NULL,
  PRIMARY KEY  (`cod_iva`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `alicuota_iva`
--

LOCK TABLES alicuota_iva WRITE;
INSERT INTO alicuota_iva VALUES('1', 'TASA GENERAL 21%', '21');
INSERT INTO alicuota_iva VALUES('2', 'TASA GENERAL 10.5%', '10.5');
INSERT INTO alicuota_iva VALUES('6', 'SIN IVA', '0');
UNLOCK TABLES;


--
-- Table structure for table `art_especial`
--

DROP TABLE IF EXISTS art_especial;
CREATE TABLE `art_especial` (
  `codigo` int(11) NOT NULL,
  `tipo` char(2) NOT NULL,
  `valor` varchar(30) default NULL,
  PRIMARY KEY  (`codigo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `art_especial`
--

LOCK TABLES art_especial WRITE;
INSERT INTO art_especial VALUES('13211', 'NC', 'NO COMPRA');
INSERT INTO art_especial VALUES('13321', 'SF', 'SIN FACTURA');
UNLOCK TABLES;


--
-- Table structure for table `caja_inicial`
--

DROP TABLE IF EXISTS caja_inicial;
CREATE TABLE `caja_inicial` (
  `fecha` int(11) NOT NULL,
  `importe` float NOT NULL,
  `observacion` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `caja_inicial`
--

LOCK TABLES caja_inicial WRITE;
INSERT INTO caja_inicial VALUES('20090502', '1000', 'NADA');
UNLOCK TABLES;


--
-- Table structure for table `cargas`
--

DROP TABLE IF EXISTS cargas;
CREATE TABLE `cargas` (
  `fecha` int(11) NOT NULL,
  `cod_flero` int(11) NOT NULL,
  `hora` text NOT NULL,
  `usuario` text NOT NULL,
  PRIMARY KEY  (`fecha`,`cod_flero`),
  KEY `Reffletero116` (`cod_flero`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cargas`
--

LOCK TABLES cargas WRITE;
INSERT INTO cargas VALUES('20090124', '1', '19:07:26', 'admin');
UNLOCK TABLES;


--
-- Table structure for table `categoria`
--

DROP TABLE IF EXISTS categoria;
CREATE TABLE `categoria` (
  `cod_categoria` int(11) NOT NULL auto_increment,
  `descripcion` text,
  PRIMARY KEY  (`cod_categoria`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categoria`
--

LOCK TABLES categoria WRITE;
INSERT INTO categoria VALUES('1', 'PUB. GRAL.');
INSERT INTO categoria VALUES('2', 'ADM. PUBLICA');
UNLOCK TABLES;


--
-- Table structure for table `cc_compra`
--

DROP TABLE IF EXISTS cc_compra;
CREATE TABLE `cc_compra` (
  `n_factura` int(8) unsigned zerofill NOT NULL,
  `total` float NOT NULL,
  `estado` text NOT NULL,
  PRIMARY KEY  (`n_factura`),
  KEY `Ref3746` (`n_factura`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cc_compra`
--

LOCK TABLES cc_compra WRITE;
UNLOCK TABLES;


--
-- Table structure for table `cc_compra_detalle`
--

DROP TABLE IF EXISTS cc_compra_detalle;
CREATE TABLE `cc_compra_detalle` (
  `n_factura` int(8) unsigned zerofill NOT NULL,
  `n_compr` int(11) NOT NULL,
  `fecha` int(11) NOT NULL,
  `monto` float NOT NULL,
  `observacion` text,
  `cod_fp` int(11) NOT NULL,
  PRIMARY KEY  (`n_factura`),
  KEY `Ref3447` (`n_factura`),
  KEY `Ref2655` (`cod_fp`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cc_compra_detalle`
--

LOCK TABLES cc_compra_detalle WRITE;
UNLOCK TABLES;


--
-- Table structure for table `cc_vta`
--

DROP TABLE IF EXISTS cc_vta;
CREATE TABLE `cc_vta` (
  `num_recibo` int(8) unsigned zerofill NOT NULL,
  `cod_cliente` int(11) NOT NULL,
  `cod_zona` int(11) NOT NULL,
  `cod_localidad` int(11) NOT NULL,
  `cod_prov` int(11) NOT NULL,
  `cod_pais` int(11) NOT NULL,
  `cod_talonario` char(1) NOT NULL,
  `num_talonario` int(4) unsigned zerofill NOT NULL,
  `importe` float NOT NULL,
  `cod_vendedor` int(11) NOT NULL,
  `fecha` int(11) default NULL,
  `observacion` text,
  `usuario` text,
  PRIMARY KEY  (`num_recibo`,`cod_cliente`,`cod_zona`,`cod_localidad`,`cod_prov`,`cod_pais`,`cod_talonario`,`num_talonario`),
  KEY `Refrecibos_por_cliente131` (`cod_cliente`,`cod_zona`,`cod_localidad`,`cod_prov`,`cod_pais`,`cod_talonario`,`num_talonario`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cc_vta`
--

LOCK TABLES cc_vta WRITE;
INSERT INTO cc_vta VALUES('00000001', '1', '5', '33', '1', '1', 'C', '0001', '100', '1', '20090124', '', 'admin');
INSERT INTO cc_vta VALUES('00000002', '1', '5', '33', '1', '1', 'C', '0001', '100', '1', '20090124', '', 'admin');
UNLOCK TABLES;


--
-- Table structure for table `cc_vta_detalle`
--

DROP TABLE IF EXISTS cc_vta_detalle;
CREATE TABLE `cc_vta_detalle` (
  `id_imputacion` int(11) NOT NULL auto_increment,
  `n_factura` int(8) unsigned zerofill NOT NULL,
  `cod_talonario` char(1) NOT NULL,
  `num_talonario` int(4) unsigned zerofill NOT NULL,
  `num_recibo` int(8) unsigned zerofill default NULL,
  `cod_talonario_recibo` char(1) default NULL,
  `num_talonario_recibo` int(4) unsigned zerofill default NULL,
  `importe` float NOT NULL,
  `fecha` int(11) NOT NULL,
  `observacion` text,
  `usuario` text,
  PRIMARY KEY  (`id_imputacion`),
  KEY `Reffactura_vta128` (`n_factura`,`cod_talonario`,`num_talonario`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cc_vta_detalle`
--

LOCK TABLES cc_vta_detalle WRITE;
INSERT INTO cc_vta_detalle VALUES('1', '00000001', 'A', '0001', '00000001', 'C', '0001', '50', '20090124', '', 'admin');
INSERT INTO cc_vta_detalle VALUES('2', '00000001', 'A', '0001', '00000002', 'C', '0001', '50', '20090124', '', 'admin');
INSERT INTO cc_vta_detalle VALUES('3', '00000003', 'A', '0001', '00000002', 'C', '0001', '50', '20090124', '', 'admin');
INSERT INTO cc_vta_detalle VALUES('4', '00000003', 'A', '0001', '00000001', 'C', '0001', '46.7', '20090124', '', 'admin');
UNLOCK TABLES;


--
-- Table structure for table `cc_vta_tmp`
--

DROP TABLE IF EXISTS cc_vta_tmp;
CREATE TABLE `cc_vta_tmp` (
  `usuario` text,
  `n_factura` int(8) unsigned zerofill NOT NULL,
  `cod_talonario` char(1) NOT NULL,
  `num_talonario` int(4) unsigned zerofill NOT NULL,
  `importe` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cc_vta_tmp`
--

LOCK TABLES cc_vta_tmp WRITE;
UNLOCK TABLES;


--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS cliente;
CREATE TABLE `cliente` (
  `cod_cliente` int(11) NOT NULL,
  `cod_zona` int(11) NOT NULL,
  `cod_localidad` int(11) NOT NULL,
  `cod_prov` int(11) NOT NULL,
  `cod_pais` int(11) NOT NULL,
  `nombre` text NOT NULL,
  `razon_social` text NOT NULL,
  `tel` text,
  `fax` text,
  `movil` text,
  `direccion` text NOT NULL,
  `cuit` text,
  `limite_credito` text,
  `web` text,
  `email` text,
  `cod_iva` int(11) NOT NULL,
  `cod_categoria` int(11) NOT NULL,
  `cod_vendedor` int(11) NOT NULL,
  `cod_flero` int(11) NOT NULL,
  `cod_talonario` char(1) NOT NULL,
  `cod_fp` int(11) NOT NULL,
  `orden` int(11) NOT NULL,
  `activo` varchar(1) NOT NULL,
  PRIMARY KEY  (`cod_cliente`,`cod_zona`,`cod_localidad`,`cod_prov`,`cod_pais`),
  KEY `Ref1814` (`cod_pais`,`cod_prov`,`cod_localidad`,`cod_zona`),
  KEY `Ref2830` (`cod_iva`,`cod_talonario`),
  KEY `Ref475` (`cod_categoria`),
  KEY `Ref4582` (`cod_vendedor`),
  KEY `Ref683` (`cod_flero`),
  KEY `Ref2584` (`cod_talonario`),
  KEY `Ref26113` (`cod_fp`),
  KEY `Refzona14` (`cod_zona`,`cod_localidad`,`cod_prov`,`cod_pais`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cliente`
--

LOCK TABLES cliente WRITE;
INSERT INTO cliente VALUES('1', '5', '33', '1', '1', 'TITO', 'DOS MIL S.A.', '03758-422504', '03758-422504', '', 'LOTE 52 -', '30687923878', '', '', '', '1', '1', '1', '1', 'A', '3', '17', 'S');
INSERT INTO cliente VALUES('2', '5', '33', '1', '1', '', 'HORODESKI ADOLFO  BLAS', '', '', '', 'SARMIENTO Y ALVEAR', '20279817991', '', '', '', '2', '1', '1', '1', 'B', '1', '0', 'S');
INSERT INTO cliente VALUES('3', '5', '33', '1', '1', '', 'CATALANO SERGIO', '', '', '', 'H.RAMELLA - FTE. P.LA ESPIGA', '20147459131', '', '', '', '2', '1', '1', '1', 'B', '1', '0', 'S');
INSERT INTO cliente VALUES('4', '5', '33', '1', '1', '', 'DA LUZ SALVADOR', '', '', '', 'ALVEAR Y RUTA 105', '23207572349', '', '', '', '1', '1', '1', '1', 'A', '1', '80', 'S');
INSERT INTO cliente VALUES('5', '5', '33', '1', '1', '', 'KRAUCHUK JOSE', '', '', '', 'BELGRANO 1012', '20124163367', '', '', '', '1', '1', '1', '1', 'A', '1', '6', 'S');
INSERT INTO cliente VALUES('6', '5', '33', '1', '1', '', 'PROKOPIW JULIO CESAR', '', '', '', 'HUSSAY Y LIBERTAD', '20184625890', '', '', '', '2', '1', '1', '1', 'B', '1', '118', 'S');
UNLOCK TABLES;


--
-- Table structure for table `comision_vendedor`
--

DROP TABLE IF EXISTS comision_vendedor;
CREATE TABLE `comision_vendedor` (
  `cod_vendedor` int(11) NOT NULL,
  `fecha_desde` int(11) NOT NULL,
  `fecha_hasta` int(11) NOT NULL,
  `fecha_liq` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comision_vendedor`
--

LOCK TABLES comision_vendedor WRITE;
INSERT INTO comision_vendedor VALUES('20', '20071115', '20071115', '20071115');
INSERT INTO comision_vendedor VALUES('17', '20071101', '20071117', '20071117');
INSERT INTO comision_vendedor VALUES('3', '20071112', '20071123', '20071124');
INSERT INTO comision_vendedor VALUES('3', '20071201', '20071210', '20071212');
INSERT INTO comision_vendedor VALUES('10', '20071101', '20071130', '20071219');
INSERT INTO comision_vendedor VALUES('5', '20080101', '20080115', '20080116');
INSERT INTO comision_vendedor VALUES('17', '20080101', '20080131', '20080202');
INSERT INTO comision_vendedor VALUES('10', '20080101', '20080131', '20080206');
INSERT INTO comision_vendedor VALUES('2', '20080101', '20080131', '20080209');
INSERT INTO comision_vendedor VALUES('14', '20080101', '20080131', '20080209');
INSERT INTO comision_vendedor VALUES('1', '20080128', '20080217', '20080220');
INSERT INTO comision_vendedor VALUES('5', '20080128', '20080203', '20080227');
INSERT INTO comision_vendedor VALUES('5', '20080204', '20080220', '20080227');
INSERT INTO comision_vendedor VALUES('6', '20080111', '20080126', '20080228');
INSERT INTO comision_vendedor VALUES('6', '20080211', '20080226', '20080228');
INSERT INTO comision_vendedor VALUES('6', '20080128', '20080202', '20080228');
INSERT INTO comision_vendedor VALUES('6', '20080204', '20080221', '20080228');
INSERT INTO comision_vendedor VALUES('2', '20080201', '20080229', '20080307');
INSERT INTO comision_vendedor VALUES('14', '20080201', '20080229', '20080307');
INSERT INTO comision_vendedor VALUES('15', '20080329', '20080329', '20080405');
INSERT INTO comision_vendedor VALUES('2', '20080301', '20080331', '20080405');
INSERT INTO comision_vendedor VALUES('14', '20080301', '20080331', '20080405');
INSERT INTO comision_vendedor VALUES('4', '20080425', '20080425', '20080430');
INSERT INTO comision_vendedor VALUES('15', '20080426', '20080426', '20080505');
INSERT INTO comision_vendedor VALUES('4', '20080502', '20080502', '20080506');
INSERT INTO comision_vendedor VALUES('4', '20080506', '20080506', '20080508');
INSERT INTO comision_vendedor VALUES('2', '20080401', '20080430', '20080510');
INSERT INTO comision_vendedor VALUES('14', '20080401', '20080430', '20080510');
INSERT INTO comision_vendedor VALUES('15', '20080503', '20080503', '20080510');
INSERT INTO comision_vendedor VALUES('4', '20080509', '20080509', '20080513');
INSERT INTO comision_vendedor VALUES('4', '20080520', '20080520', '20080522');
INSERT INTO comision_vendedor VALUES('4', '20080523', '20080523', '20080528');
INSERT INTO comision_vendedor VALUES('4', '20080527', '20080527', '20080530');
INSERT INTO comision_vendedor VALUES('15', '20080524', '20080524', '20080531');
INSERT INTO comision_vendedor VALUES('4', '20080530', '20080530', '20080603');
INSERT INTO comision_vendedor VALUES('4', '20080603', '20080603', '20080606');
INSERT INTO comision_vendedor VALUES('15', '20080531', '20080531', '20080606');
INSERT INTO comision_vendedor VALUES('4', '20080606', '20080606', '20080610');
INSERT INTO comision_vendedor VALUES('4', '20080610', '20080610', '20080613');
INSERT INTO comision_vendedor VALUES('4', '20080613', '20080613', '20080618');
INSERT INTO comision_vendedor VALUES('4', '20080617', '20080617', '20080621');
INSERT INTO comision_vendedor VALUES('15', '20080607', '20080607', '20080621');
INSERT INTO comision_vendedor VALUES('15', '20080614', '20080614', '20080621');
INSERT INTO comision_vendedor VALUES('4', '20080620', '20080620', '20080625');
INSERT INTO comision_vendedor VALUES('4', '20080624', '20080624', '20080627');
INSERT INTO comision_vendedor VALUES('15', '20080622', '20080622', '20080628');
INSERT INTO comision_vendedor VALUES('15', '20080621', '20080621', '20080628');
INSERT INTO comision_vendedor VALUES('6', '20080616', '20080630', '20080701');
INSERT INTO comision_vendedor VALUES('4', '20080627', '20080627', '20080701');
INSERT INTO comision_vendedor VALUES('4', '20080701', '20080701', '20080704');
INSERT INTO comision_vendedor VALUES('17', '20080601', '20080630', '20080705');
INSERT INTO comision_vendedor VALUES('15', '20080628', '20080628', '20080705');
INSERT INTO comision_vendedor VALUES('4', '20080704', '20080704', '20080707');
INSERT INTO comision_vendedor VALUES('4', '20080707', '20080707', '20080711');
INSERT INTO comision_vendedor VALUES('15', '20080705', '20080705', '20080712');
INSERT INTO comision_vendedor VALUES('4', '20080711', '20080711', '20080722');
INSERT INTO comision_vendedor VALUES('4', '20080715', '20080715', '20080722');
INSERT INTO comision_vendedor VALUES('4', '20080718', '20080718', '20080722');
INSERT INTO comision_vendedor VALUES('4', '20080722', '20080722', '20080725');
INSERT INTO comision_vendedor VALUES('15', '20080719', '20080719', '20080726');
INSERT INTO comision_vendedor VALUES('15', '20080712', '20080712', '20080726');
INSERT INTO comision_vendedor VALUES('4', '20080725', '20080725', '20080729');
INSERT INTO comision_vendedor VALUES('4', '20080729', '20080729', '20080801');
INSERT INTO comision_vendedor VALUES('15', '20080726', '20080726', '20080802');
INSERT INTO comision_vendedor VALUES('4', '20080801', '20080801', '20080805');
INSERT INTO comision_vendedor VALUES('14', '20080701', '20080731', '20080807');
INSERT INTO comision_vendedor VALUES('2', '20080701', '20080731', '20080807');
INSERT INTO comision_vendedor VALUES('4', '20080805', '20080805', '20080808');
INSERT INTO comision_vendedor VALUES('15', '20080802', '20080802', '20080809');
INSERT INTO comision_vendedor VALUES('4', '20080808', '20080808', '20080812');
INSERT INTO comision_vendedor VALUES('4', '20080812', '20080812', '20080815');
INSERT INTO comision_vendedor VALUES('15', '20080809', '20080809', '20080815');
INSERT INTO comision_vendedor VALUES('4', '20080815', '20080815', '20080819');
INSERT INTO comision_vendedor VALUES('4', '20080819', '20080819', '20080822');
INSERT INTO comision_vendedor VALUES('15', '20080816', '20080816', '20080822');
INSERT INTO comision_vendedor VALUES('4', '20080822', '20080822', '20080825');
INSERT INTO comision_vendedor VALUES('4', '20080826', '20080826', '20080828');
INSERT INTO comision_vendedor VALUES('15', '20080823', '20080823', '20080829');
INSERT INTO comision_vendedor VALUES('15', '20080820', '20080820', '20080901');
INSERT INTO comision_vendedor VALUES('4', '20080829', '20080829', '20080901');
INSERT INTO comision_vendedor VALUES('4', '20080905', '20080905', '20080909');
INSERT INTO comision_vendedor VALUES('6', '20080817', '20080905', '20080909');
INSERT INTO comision_vendedor VALUES('4', '20080909', '20080909', '20080911');
INSERT INTO comision_vendedor VALUES('15', '20080904', '20080904', '20080912');
INSERT INTO comision_vendedor VALUES('15', '20080906', '20080906', '20080912');
INSERT INTO comision_vendedor VALUES('15', '20080830', '20080830', '20080912');
INSERT INTO comision_vendedor VALUES('15', '20080829', '20080829', '20080912');
INSERT INTO comision_vendedor VALUES('4', '20080912', '20080912', '20080915');
INSERT INTO comision_vendedor VALUES('4', '20080913', '20080913', '20080918');
INSERT INTO comision_vendedor VALUES('4', '20080916', '20080916', '20080919');
INSERT INTO comision_vendedor VALUES('15', '20080917', '20080917', '20080920');
INSERT INTO comision_vendedor VALUES('15', '20080913', '20080913', '20080920');
INSERT INTO comision_vendedor VALUES('4', '20080919', '20080919', '20080922');
INSERT INTO comision_vendedor VALUES('4', '20080922', '20080922', '20080923');
INSERT INTO comision_vendedor VALUES('4', '20080920', '20080920', '20080923');
INSERT INTO comision_vendedor VALUES('4', '20080923', '20080923', '20080924');
INSERT INTO comision_vendedor VALUES('4', '20080924', '20080924', '20080926');
INSERT INTO comision_vendedor VALUES('4', '20080925', '20080925', '20080926');
INSERT INTO comision_vendedor VALUES('15', '20080920', '20080920', '20080926');
INSERT INTO comision_vendedor VALUES('4', '20080926', '20080926', '20080929');
INSERT INTO comision_vendedor VALUES('4', '20080929', '20080929', '20080929');
INSERT INTO comision_vendedor VALUES('4', '20080930', '20080930', '20081003');
INSERT INTO comision_vendedor VALUES('4', '20081001', '20081001', '20081003');
INSERT INTO comision_vendedor VALUES('4', '20081002', '20081002', '20081003');
INSERT INTO comision_vendedor VALUES('15', '20080927', '20080927', '20081003');
INSERT INTO comision_vendedor VALUES('4', '20081003', '20081003', '20081006');
INSERT INTO comision_vendedor VALUES('4', '20081007', '20081007', '20081008');
INSERT INTO comision_vendedor VALUES('2', '20080901', '20080930', '20081009');
INSERT INTO comision_vendedor VALUES('15', '20081004', '20081004', '20081011');
INSERT INTO comision_vendedor VALUES('14', '20080901', '20080930', '20081014');
INSERT INTO comision_vendedor VALUES('4', '20081010', '20081010', '20081014');
INSERT INTO comision_vendedor VALUES('15', '20081011', '20081011', '20081017');
INSERT INTO comision_vendedor VALUES('4', '20081014', '20081014', '20081017');
INSERT INTO comision_vendedor VALUES('4', '20081017', '20081017', '20081020');
INSERT INTO comision_vendedor VALUES('4', '20081021', '20081021', '20081022');
INSERT INTO comision_vendedor VALUES('15', '20081018', '20081018', '20081022');
INSERT INTO comision_vendedor VALUES('4', '20081024', '20081024', '20081027');
INSERT INTO comision_vendedor VALUES('4', '20081028', '20081028', '20081029');
INSERT INTO comision_vendedor VALUES('15', '20081025', '20081025', '20081029');
INSERT INTO comision_vendedor VALUES('4', '20081031', '20081031', '20081103');
INSERT INTO comision_vendedor VALUES('4', '20081104', '20081104', '20081106');
INSERT INTO comision_vendedor VALUES('15', '20081101', '20081101', '20081108');
INSERT INTO comision_vendedor VALUES('4', '20081107', '20081107', '20081110');
INSERT INTO comision_vendedor VALUES('4', '20081111', '20081111', '20081113');
INSERT INTO comision_vendedor VALUES('15', '20081108', '20081108', '20081113');
INSERT INTO comision_vendedor VALUES('4', '20081114', '20081114', '20081117');
INSERT INTO comision_vendedor VALUES('4', '20081118', '20081118', '20081121');
INSERT INTO comision_vendedor VALUES('15', '20081114', '20081114', '20081121');
INSERT INTO comision_vendedor VALUES('4', '20081121', '20081121', '20081124');
INSERT INTO comision_vendedor VALUES('4', '20081125', '20081125', '20081128');
INSERT INTO comision_vendedor VALUES('15', '20081122', '20081122', '20081129');
INSERT INTO comision_vendedor VALUES('4', '20081128', '20081128', '20081202');
INSERT INTO comision_vendedor VALUES('4', '20081201', '20081204', '20081204');
UNLOCK TABLES;


--
-- Table structure for table `conf_listados`
--

DROP TABLE IF EXISTS conf_listados;
CREATE TABLE `conf_listados` (
  `lineas` int(11) NOT NULL,
  `impresora` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `conf_listados`
--

LOCK TABLES conf_listados WRITE;
INSERT INTO conf_listados VALUES('35', 'LaserJet-P1005#LaserJet-P1005');
UNLOCK TABLES;


--
-- Table structure for table `deposito`
--

DROP TABLE IF EXISTS deposito;
CREATE TABLE `deposito` (
  `id` int(11) NOT NULL auto_increment,
  `fecha` int(11) NOT NULL,
  `hora` char(20) NOT NULL,
  `banco` text NOT NULL,
  `n_trans` char(20) NOT NULL,
  `n_cta` char(20) NOT NULL,
  `titular` text,
  `importe` float NOT NULL,
  `observacion` char(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `deposito`
--

LOCK TABLES deposito WRITE;
INSERT INTO deposito VALUES('1', '20090101', '12', 'NACION', '1', '1', 'BETOS', '100', 'NADA');
INSERT INTO deposito VALUES('2', '20090102', '12', 'NACION', '2', '2', 'FABISS', '100', 'NADA');
INSERT INTO deposito VALUES('3', '20090103', '12', 'NACION', '3', '3', 'JUAN PERZ', '100', 'MONITORES LCD');
UNLOCK TABLES;


--
-- Table structure for table `devolucion`
--

DROP TABLE IF EXISTS devolucion;
CREATE TABLE `devolucion` (
  `n_devolucion` int(8) unsigned zerofill NOT NULL,
  `cod_vendedor` int(11) default NULL,
  `cod_talonario` char(1) default NULL,
  `num_talonario` int(4) unsigned zerofill default NULL,
  `fecha_rebote` int(11) default NULL,
  `fecha_carga` int(11) NOT NULL,
  PRIMARY KEY  (`n_devolucion`),
  KEY `Reftalonario117` (`cod_talonario`,`num_talonario`),
  KEY `Refvendedor118` (`cod_vendedor`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `devolucion`
--

LOCK TABLES devolucion WRITE;
UNLOCK TABLES;


--
-- Table structure for table `devolucion_detalle`
--

DROP TABLE IF EXISTS devolucion_detalle;
CREATE TABLE `devolucion_detalle` (
  `n_devolucion` int(8) unsigned zerofill NOT NULL,
  `cod_prod` int(11) NOT NULL,
  `cod_variedad` int(11) NOT NULL,
  `cod_marca` int(11) NOT NULL,
  `cod_grupo` int(11) NOT NULL,
  `cantidad` float default NULL,
  `precio` float NOT NULL,
  PRIMARY KEY  (`n_devolucion`,`cod_prod`,`cod_variedad`,`cod_marca`,`cod_grupo`),
  KEY `Refproducto120` (`cod_prod`,`cod_variedad`,`cod_marca`,`cod_grupo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `devolucion_detalle`
--

LOCK TABLES devolucion_detalle WRITE;
UNLOCK TABLES;


--
-- Table structure for table `devolucion_detalle_tmp`
--

DROP TABLE IF EXISTS devolucion_detalle_tmp;
CREATE TABLE `devolucion_detalle_tmp` (
  `usuario` text,
  `cod_prod` int(11) default NULL,
  `descripcion` text NOT NULL,
  `precio` float NOT NULL,
  `cantidad` float NOT NULL,
  `linea` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `devolucion_detalle_tmp`
--

LOCK TABLES devolucion_detalle_tmp WRITE;
UNLOCK TABLES;


--
-- Table structure for table `empresa`
--

DROP TABLE IF EXISTS empresa;
CREATE TABLE `empresa` (
  `cod_empresa` int(11) NOT NULL auto_increment,
  `dueno` text NOT NULL,
  `razon_social` text NOT NULL,
  `cuit` text,
  `ing_bruto` text,
  `iva` text NOT NULL,
  `inicio_act` int(11) default NULL,
  `tel` text,
  `fax` text,
  `movil` text,
  `direccion` text NOT NULL,
  `pais` text NOT NULL,
  `provincia` text NOT NULL,
  `localidad` text NOT NULL,
  `web` text,
  `email` text,
  `logo` text,
  `imagen_fondo` text,
  PRIMARY KEY  (`cod_empresa`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `empresa`
--

LOCK TABLES empresa WRITE;
INSERT INTO empresa VALUES('1', 'CLAUDIO', 'DOS INSUMOS INFORMATICOS', '30710115393', '11111111', 'RESP. INSCRIPTO', '24012009', '(03752) 433535', '(03752) 433535', '', 'SAN LORENZO 1671', 'ARGENTINA', 'MISIONES', 'POSADAS', 'WWW.DOS-INSUMOS.COM.AR', 'INFO@DOS-INSUMOS.COM.AR', 'N', 'N');
UNLOCK TABLES;


--
-- Table structure for table `evento`
--

DROP TABLE IF EXISTS evento;
CREATE TABLE `evento` (
  `id` int(11) NOT NULL auto_increment,
  `body` text,
  `timestamp` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=172 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `evento`
--

LOCK TABLES evento WRITE;
INSERT INTO evento VALUES('2', '1 frezeer azara; casamiento; gerardo', '1201316400');
INSERT INTO evento VALUES('3', '9 freezer concepcion carnaval', '1201316400');
INSERT INTO evento VALUES('15', '1 freezer expo yerba krayeski', '1201921200');
INSERT INTO evento VALUES('6', '9 freezer concepcion carnaval', '1202526000');
INSERT INTO evento VALUES('9', '1 freezer Alem casamiento', '1200711600');
INSERT INTO evento VALUES('10', '2 freezer skulkin recital', '1200538800');
INSERT INTO evento VALUES('11', '2 freezer yayechesen Adolfo\nCentenario de los viejitos', '1203130800');
INSERT INTO evento VALUES('16', '5 freezer concepcion carnaval', '1201921200');
INSERT INTO evento VALUES('13', '2 freezer gerardo', '1201921200');
INSERT INTO evento VALUES('14', '2 freezer skulkin kermes apostoles\n', '1201834800');
INSERT INTO evento VALUES('17', 'prates guillermo 3 freezers\n', '1203130800');
INSERT INTO evento VALUES('22', '2 freezer skulkin', '1203735600');
INSERT INTO evento VALUES('19', 'galeano 2 freezers conce. sierra', '1203130800');
INSERT INTO evento VALUES('21', '4 freezer-zacovich jose-azara. anivesario', '1205463600');
INSERT INTO evento VALUES('23', '1 freezer amarilla - recalde\n', '1203130800');
INSERT INTO evento VALUES('28', '1 freezer policia', '1204945200');
INSERT INTO evento VALUES('25', '1 freezer - bordaquievich - concepcion', '1204254000');
INSERT INTO evento VALUES('26', '2 freezer concepcion-comisaria', '1204254000');
INSERT INTO evento VALUES('27', '2 freezer don andres - p/virasoro', '1207191600');
INSERT INTO evento VALUES('29', '2 freezer kseminski lidia 3 capones', '1204945200');
INSERT INTO evento VALUES('31', '2 freezer munes electricista - apostoles', '1206154800');
INSERT INTO evento VALUES('32', '4 freezer alexis - c.azul\n', '1206759600');
INSERT INTO evento VALUES('33', '1 freezer gacek', '1205463600');
INSERT INTO evento VALUES('34', '2 freezer comision B.200 - Apost.', '1206759600');
INSERT INTO evento VALUES('40', '2 freezer - gonzales policia\n', '1208574000');
INSERT INTO evento VALUES('38', '3 freezer skulkin', '1207278000');
INSERT INTO evento VALUES('39', '3 freezer - Concepcion sta. Rosa', '1207969200');
INSERT INTO evento VALUES('44', '2 freezer - gerardo', '1209178800');
INSERT INTO evento VALUES('45', '2 freezer - gerardo\n', '1209610800');
INSERT INTO evento VALUES('46', '1 freezer fabian dos mil\n', '1209178800');
INSERT INTO evento VALUES('47', '2 freezer - Escuela trad. danza. Azara', '1210388400');
INSERT INTO evento VALUES('48', '2 freezer - Comisaria de Concepcion', '1209610800');
INSERT INTO evento VALUES('49', '2 freezer - Comisaria de Concepcion', '1209783600');
INSERT INTO evento VALUES('50', '3 freezer - El Guri (Da luz)', '1211598000');
INSERT INTO evento VALUES('51', '8 freezer - Carrera Auto Apostoles', '1210388400');
INSERT INTO evento VALUES('56', '2 freezer - casamiento concepcion salon de kuki.', '1221879600');
INSERT INTO evento VALUES('53', '1 freezer - cooperativa de liebig\n', '1210993200');
INSERT INTO evento VALUES('68', '1 FREEZER - SAN RAMON - APOSTOLES', '1212721200');
INSERT INTO evento VALUES('57', '2 freezer - gacek -gerardo', '1211598000');
INSERT INTO evento VALUES('58', '1 freezer - PABES CARLOS - gendarme', '1211511600');
INSERT INTO evento VALUES('59', '2 freezer - graboviesky', '1211598000');
INSERT INTO evento VALUES('62', 'herrera ricardo 9 de julio y mitre \n3 freezers', '1213412400');
INSERT INTO evento VALUES('64', 'Enc. de Moto - 2 grosko; 1 Tiberio; 2 Alcantara Veronica', '1212721200');
INSERT INTO evento VALUES('65', '1 freezer - Aguirre Jose - Azara', '1212202800');
INSERT INTO evento VALUES('66', 'CABRERA 1 FREEZER', '1212721200');
INSERT INTO evento VALUES('67', '2 FREEZER - LEGUIZA MIGUEL - SAN CARLOS\n', '1212634800');
INSERT INTO evento VALUES('69', '2 freezer - 3 capones\n', '1216436400');
INSERT INTO evento VALUES('70', 'semana de aniversario casino \n4 freezers', '1216263600');
INSERT INTO evento VALUES('71', '2 freezer - galarza', '1214622000');
INSERT INTO evento VALUES('72', '2 freezer - PEDROZO DIEGO - concepcion', '1215226800');
INSERT INTO evento VALUES('73', '2 freezer - PEDROZO DIEGO - concepcion', '1215831600');
INSERT INTO evento VALUES('74', '2 freezer - PEDROZO DIEGO - concepcion', '1216436400');
INSERT INTO evento VALUES('75', 'semana de aniversario casino\n4 freezers', '1216350000');
INSERT INTO evento VALUES('76', 'semana de aniversario casino\n4 freezers', '1216436400');
INSERT INTO evento VALUES('77', 'semana de aniversario casino\n4 freezers', '1216522800');
INSERT INTO evento VALUES('78', '1 freezer - LA CORITA VERD - ITACARUARE', '1215226800');
INSERT INTO evento VALUES('79', '1 frezer - juancho', '1215745200');
INSERT INTO evento VALUES('81', '2 FREEZER - PAULO DERCACH - AZARA', '1216436400');
INSERT INTO evento VALUES('82', '2 freezer - CAPILLA DE LIEBIG', '1215831600');
INSERT INTO evento VALUES('83', '2 freezer - LEDEZMA', '1215831600');
INSERT INTO evento VALUES('84', '2 FREEZER - OSCAR EXPO YERBA', '1215831600');
INSERT INTO evento VALUES('85', '1 freezer - prate', '1218855600');
INSERT INTO evento VALUES('86', '2 freezer - kachuk - concepcion', '1218250800');
INSERT INTO evento VALUES('87', '2 freezer - herrera ricardo - apostoles', '1219460400');
INSERT INTO evento VALUES('91', '5 FREEZER - GRAB. MARIO', '1218855600');
INSERT INTO evento VALUES('89', '1 freezer - guti apostoles', '1218855600');
INSERT INTO evento VALUES('90', '3 freezer - SAN JOSE', '1218855600');
INSERT INTO evento VALUES('92', '1 FREEZER - GARRUCHOS\n', '1218250800');
INSERT INTO evento VALUES('93', '10 freezer - virasoro fiesta la rural', '1220410800');
INSERT INTO evento VALUES('94', '10 freezer - virasoro fiesta la rural', '1220497200');
INSERT INTO evento VALUES('95', '10 freezer - virasoro fiesta la rural', '1220583600');
INSERT INTO evento VALUES('96', '10 freezer - virasoro fiesta la rural', '1220670000');
INSERT INTO evento VALUES('97', '10 freezer - virasoro fiesta la rural', '1220756400');
INSERT INTO evento VALUES('98', '4 freezer - expo yerba domingo scrapnik - ', '1221879600');
INSERT INTO evento VALUES('99', '2 freezer ajipam - apostoles', '1221793200');
INSERT INTO evento VALUES('100', '2 freezer club colonial - c.azul - recalde', '1221274800');
INSERT INTO evento VALUES('101', '8 freezer - carrera - apostoles', '1219460400');
INSERT INTO evento VALUES('102', '4 freezer fiesta santa rosa concep. Da Luz', '1220065200');
INSERT INTO evento VALUES('103', 'TODOS LOS FREEZER FIESTA DE LA CERVEZA', '1223175600');
INSERT INTO evento VALUES('104', 'TODOS LOS FREEZER FIESTA DE LA CERVEZA', '1223089200');
INSERT INTO evento VALUES('105', 'TODOS LOS FREEZER FIESTA DE LA CERVEZA', '1223002800');
INSERT INTO evento VALUES('106', 'TODOS LOS FREEZER FIESTA DE LA CERVEZA', '1222916400');
INSERT INTO evento VALUES('107', '2 FREEZER - MARIO GRABOV.', '1221274800');
INSERT INTO evento VALUES('108', '3 freezer - gdor.lopez - recalde \n', '1222311600');
INSERT INTO evento VALUES('109', '2 frezer - skulkin san jose', '1221274800');
INSERT INTO evento VALUES('110', '2 freezer - krutki las tunas', '1221274800');
INSERT INTO evento VALUES('111', '1 frezeer - matias', '1221274800');
INSERT INTO evento VALUES('112', '2 freezer - fiesta capilla s. miguel.', '1223089200');
INSERT INTO evento VALUES('113', '1 freezer - azara - club ucraniano - gerardo', '1221879600');
INSERT INTO evento VALUES('116', '3 freezer - grab.mario - las tunas', '1224298800');
INSERT INTO evento VALUES('115', '1 freezer - art', '1224903600');
INSERT INTO evento VALUES('117', '4 freezer - che poya concepcion', '1222484400');
INSERT INTO evento VALUES('118', '6 freezer - fiesta de la cancion liebig', '1224212400');
INSERT INTO evento VALUES('127', '6 freezer - fiesta de la cancion - liebig', '1225422000');
INSERT INTO evento VALUES('120', '2 freezers juancho.', '1223607600');
INSERT INTO evento VALUES('121', '2 freezer - krutki', '1223607600');
INSERT INTO evento VALUES('122', '2 freezer - gerardo san jose', '1223607600');
INSERT INTO evento VALUES('123', '1 freezer - miguel virasoro', '1223607600');
INSERT INTO evento VALUES('124', '1 freezer - da luz;guri', '1223607600');
INSERT INTO evento VALUES('125', '1 freezer - gacek pedro s.jose', '1223607600');
INSERT INTO evento VALUES('126', '1 freezer - isaurralde juancho', '1224903600');
INSERT INTO evento VALUES('128', '6 freezer - fiesta de la cancion - liebig', '1225508400');
INSERT INTO evento VALUES('130', '1 freezer - casino apostoles', '1224817200');
INSERT INTO evento VALUES('131', 'todos los freezer fiesta yerba', '1225854000');
INSERT INTO evento VALUES('132', 'todos los freezer fiesta yerba', '1225940400');
INSERT INTO evento VALUES('133', 'todos los freezer fiesta yerba', '1226026800');
INSERT INTO evento VALUES('134', 'todos los freezer fiesta yerba', '1226113200');
INSERT INTO evento VALUES('135', 'todos los freezer fiesta yerba', '1226199600');
INSERT INTO evento VALUES('137', 'TODOS LOS FREEZER - fiesta de STA. CATALINA - SAN CARLOS', '1228014000');
INSERT INTO evento VALUES('138', '3 freezer - matias', '1226631600');
INSERT INTO evento VALUES('149', '1 freezer barchuk juan carlos', '1226718000');
INSERT INTO evento VALUES('140', '3 freezer - san carlos doma', '1226458800');
INSERT INTO evento VALUES('141', '2 freezer - vale eco de san jose - san jose', '1225508400');
INSERT INTO evento VALUES('144', '5 freezer - gringo barreto - molino viejo', '1227927600');
INSERT INTO evento VALUES('143', '1 freezer - ajupaprom\n', '1227322800');
INSERT INTO evento VALUES('146', '3 FREEZER - RGTO - ALEJO FERNANDEZ', '1226545200');
INSERT INTO evento VALUES('170', '2 freezer - cuñada jorge skuarek - azara club acraniano', '1234494000');
INSERT INTO evento VALUES('163', '1 freezer - mario graboviesky', '1227322800');
INSERT INTO evento VALUES('151', '5 freezer - don andres - epet', '1230087600');
INSERT INTO evento VALUES('153', 'piazza juan ramon 1freezer', '1228359600');
INSERT INTO evento VALUES('154', '3 freezer - san jose - gerardo\n', '1231556400');
INSERT INTO evento VALUES('155', '1 freezer colegio cristo rey', '1227150000');
INSERT INTO evento VALUES('168', '1 freezer - da luz - gerardo', '1228359600');
INSERT INTO evento VALUES('158', '3 freezer - pezuk - expo yerba - juancho\n', '1227322800');
INSERT INTO evento VALUES('159', '7 freezer - kazuba - fiest. normal', '1229137200');
INSERT INTO evento VALUES('162', '3 freezer - concepcion - gerardo', '1227322800');
INSERT INTO evento VALUES('164', '1 freezer san jose - romero jose', '1227927600');
INSERT INTO evento VALUES('165', '1 freezer gauchito gil ituzaingo', '1228273200');
INSERT INTO evento VALUES('166', '3 frezzer - recalde c.azul', '1229137200');
INSERT INTO evento VALUES('167', '1 freezer - vesvergi - gerardo', '1228446000');
INSERT INTO evento VALUES('169', '3 freezer - don andres - comercio\n', '1228446000');
UNLOCK TABLES;


--
-- Table structure for table `factura_anulada_numeracion`
--

DROP TABLE IF EXISTS factura_anulada_numeracion;
CREATE TABLE `factura_anulada_numeracion` (
  `cod_talonario` char(1) NOT NULL,
  `num_talonario` int(4) unsigned zerofill NOT NULL,
  `sucursal` int(11) NOT NULL,
  `n_factura` int(8) unsigned zerofill NOT NULL,
  `usuario` text NOT NULL,
  `fecha` int(11) NOT NULL,
  PRIMARY KEY  (`cod_talonario`,`num_talonario`,`sucursal`,`n_factura`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `factura_anulada_numeracion`
--

LOCK TABLES factura_anulada_numeracion WRITE;
UNLOCK TABLES;


--
-- Table structure for table `factura_compra`
--

DROP TABLE IF EXISTS factura_compra;
CREATE TABLE `factura_compra` (
  `n_factura` int(11) NOT NULL,
  `n_sucursal` int(11) NOT NULL,
  `cod_proveedor` int(11) NOT NULL,
  `fecha_fact` int(11) NOT NULL,
  `subtotal` float NOT NULL,
  `imp_interno_alicuota` float default NULL,
  `imp_interno_monto` float default NULL,
  `iva_alicuota` float NOT NULL,
  `iva_monto` float NOT NULL,
  `perc_iva_alicuota` float default NULL,
  `perc_iva_monto` float default NULL,
  `pib_alicuota` float default NULL,
  `pib_monto` float default NULL,
  `otros_alicuota` float default NULL,
  `otros_monto` float default NULL,
  `total` float NOT NULL,
  `fecha_reg` int(11) NOT NULL,
  `observacion` text,
  `usuario` text NOT NULL,
  `id_deposito` int(11) default NULL,
  PRIMARY KEY  (`n_factura`,`n_sucursal`,`cod_proveedor`),
  KEY `Refproveedor53` (`cod_proveedor`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `factura_compra`
--

LOCK TABLES factura_compra WRITE;
INSERT INTO factura_compra VALUES('11111111', '1111', '1', '20090101', '300', '0', '0', '21', '63', '0', '0', '0', '0', '0', '0', '363', '20090427', '', 'admin', '1');
INSERT INTO factura_compra VALUES('11111112', '1111', '6', '20090101', '200', '1', '2', '21', '42', '1', '2', '1', '2', '1', '2', '250', '20090427', '', 'admin', '0');
INSERT INTO factura_compra VALUES('11111113', '1111', '1', '20090101', '50', '0', '0', '21', '15', '0', '0', '0', '0', '0', '0', '65', '20090427', '', 'admin', '0');
UNLOCK TABLES;


--
-- Table structure for table `factura_compra_detalle`
--

DROP TABLE IF EXISTS factura_compra_detalle;
CREATE TABLE `factura_compra_detalle` (
  `cod_prod` int(11) default NULL,
  `cod_variedad` int(11) default NULL,
  `cod_marca` int(11) default NULL,
  `cod_grupo` int(11) default NULL,
  `n_factura` int(8) unsigned zerofill default NULL,
  `n_sucursal` int(4) unsigned zerofill default NULL,
  `cod_proveedor` int(11) default NULL,
  `precio` float NOT NULL,
  `cantidad` float NOT NULL,
  `bonificacion` float default NULL,
  `importe` float NOT NULL,
  KEY `Reffactura_compra44` (`n_factura`,`n_sucursal`,`cod_proveedor`),
  KEY `Refproducto122` (`cod_prod`,`cod_variedad`,`cod_marca`,`cod_grupo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `factura_compra_detalle`
--

LOCK TABLES factura_compra_detalle WRITE;
INSERT INTO factura_compra_detalle VALUES('1', '1', '1', '1', '11111111', '1111', '1', '18.91', '10', '2', '100');
INSERT INTO factura_compra_detalle VALUES('1', '2', '1', '1', '11111111', '1111', '1', '18.9', '10', '0', '200');
INSERT INTO factura_compra_detalle VALUES('1', '1', '1', '1', '11111112', '1111', '6', '19', '10', '0', '200');
INSERT INTO factura_compra_detalle VALUES('1', '1', '1', '1', '11111113', '1111', '1', '20.5', '1', '0', '50');
UNLOCK TABLES;


--
-- Table structure for table `factura_compra_tmp`
--

DROP TABLE IF EXISTS factura_compra_tmp;
CREATE TABLE `factura_compra_tmp` (
  `usuario` text,
  `cod_prod` int(11) default NULL,
  `descripcion` text,
  `cantidad` float NOT NULL,
  `precio` float NOT NULL,
  `bonificacion` float default NULL,
  `importe` float default NULL,
  `linea` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `factura_compra_tmp`
--

LOCK TABLES factura_compra_tmp WRITE;
UNLOCK TABLES;


--
-- Table structure for table `factura_vta`
--

DROP TABLE IF EXISTS factura_vta;
CREATE TABLE `factura_vta` (
  `n_factura` int(8) unsigned zerofill NOT NULL,
  `fecha` int(11) NOT NULL,
  `hora_entrega` text,
  `lugar` text,
  `observacion` text,
  `cod_categoria` int(11) NOT NULL,
  `cod_cliente` int(11) NOT NULL,
  `cod_zona` int(11) NOT NULL,
  `cod_localidad` int(11) NOT NULL,
  `cod_prov` int(11) NOT NULL,
  `cod_pais` int(11) NOT NULL,
  `num_remito` int(8) unsigned zerofill NOT NULL,
  `cod_talonario` char(1) NOT NULL,
  `num_talonario` int(4) unsigned zerofill NOT NULL,
  `cod_vendedor` int(11) default NULL,
  `cod_repartidor` int(11) default NULL,
  `iva` float default NULL,
  `imp_interno` float default NULL,
  `perc_iva` float default NULL,
  `ing_bruto` float default NULL,
  `usuario` text,
  `cod_fp` int(11) NOT NULL,
  PRIMARY KEY  (`n_factura`,`cod_talonario`,`num_talonario`),
  KEY `Refcliente32` (`cod_cliente`,`cod_zona`,`cod_localidad`,`cod_prov`,`cod_pais`),
  KEY `Ref532` (`cod_prov`,`cod_zona`,`cod_pais`,`cod_localidad`,`cod_cliente`),
  KEY `Ref2433` (`num_remito`),
  KEY `Ref2236` (`cod_talonario`,`num_talonario`),
  KEY `Ref26115` (`cod_fp`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `factura_vta`
--

LOCK TABLES factura_vta WRITE;
INSERT INTO factura_vta VALUES('00000001', '20090124', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000001', '20090124', '', '', '', '1', '2', '5', '33', '1', '1', '00000000', 'B', '0001', '1', '1', '0', '0', '0', '0', 'admin', '1');
INSERT INTO factura_vta VALUES('00000002', '20090124', '', '', '', '1', '3', '5', '33', '1', '1', '00000000', 'B', '0001', '1', '1', '0', '0', '0', '0', 'admin', '1');
INSERT INTO factura_vta VALUES('00000002', '20090124', '', '', '', '1', '4', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '1');
INSERT INTO factura_vta VALUES('00000003', '20090124', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000004', '20090124', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000003', '20090124', '', '', '', '1', '2', '5', '33', '1', '1', '00000000', 'B', '0001', '1', '1', '0', '0', '0', '0', 'admin', '1');
INSERT INTO factura_vta VALUES('00000005', '20090205', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'fabian', '3');
INSERT INTO factura_vta VALUES('00000006', '20090205', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'fabian', '3');
INSERT INTO factura_vta VALUES('00000007', '20090205', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'fabian', '3');
INSERT INTO factura_vta VALUES('00000008', '20090205', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'fabian', '3');
INSERT INTO factura_vta VALUES('00000009', '20090205', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000004', '20090205', '', '', '', '1', '2', '5', '33', '1', '1', '00000000', 'B', '0001', '1', '1', '0', '0', '0', '0', 'admin', '1');
INSERT INTO factura_vta VALUES('00000010', '20090205', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000005', '20090205', '', '', '', '1', '2', '5', '33', '1', '1', '00000000', 'B', '0001', '1', '1', '0', '0', '0', '0', 'admin', '1');
INSERT INTO factura_vta VALUES('00000011', '20090205', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000012', '20090205', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000013', '20090205', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000014', '20090205', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000015', '20090205', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000016', '20090205', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000017', '20090205', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000018', '20090205', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000019', '20090205', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000020', '20090205', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000021', '20090206', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000022', '20090206', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '1');
INSERT INTO factura_vta VALUES('00000023', '20090206', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000024', '20090206', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000025', '20090206', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000026', '20090206', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000027', '20090206', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000028', '20090206', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000029', '20090206', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000030', '20090206', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', '', '1');
INSERT INTO factura_vta VALUES('00000006', '20090206', '', '', '', '1', '2', '5', '33', '1', '1', '00000000', 'B', '0001', '1', '1', '0', '0', '0', '0', '', '1');
INSERT INTO factura_vta VALUES('00000031', '20090206', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', '', '3');
INSERT INTO factura_vta VALUES('00000007', '20090206', '', '', '', '1', '2', '5', '33', '1', '1', '00000000', 'B', '0001', '1', '1', '0', '0', '0', '0', '', '1');
INSERT INTO factura_vta VALUES('00000032', '20090206', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', '', '3');
INSERT INTO factura_vta VALUES('00000033', '20090206', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', '', '3');
INSERT INTO factura_vta VALUES('00000034', '20090206', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', '', '3');
INSERT INTO factura_vta VALUES('00000035', '20090206', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', '', '1');
INSERT INTO factura_vta VALUES('00000008', '20090206', '', '', '', '1', '2', '5', '33', '1', '1', '00000000', 'B', '0001', '1', '1', '0', '0', '0', '0', '', '1');
INSERT INTO factura_vta VALUES('00000036', '20090206', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', '', '1');
INSERT INTO factura_vta VALUES('00000037', '20090211', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000038', '20090217', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000039', '20090217', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000040', '20090217', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000041', '20090217', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000042', '20090217', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000043', '20090217', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000044', '20090217', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000045', '20090217', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000046', '20090217', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000047', '20090217', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', '', '3');
INSERT INTO factura_vta VALUES('00000048', '20090217', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000049', '20090217', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000050', '20090218', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '1');
INSERT INTO factura_vta VALUES('00000051', '20090226', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000052', '20090226', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000053', '20090226', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000054', '20090226', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000055', '20090226', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000056', '20090226', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000057', '20090226', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000058', '20090226', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000059', '20090226', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000060', '20090226', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000061', '20090226', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000009', '20090226', '', '', '', '1', '2', '5', '33', '1', '1', '00000000', 'B', '0001', '1', '1', '0', '0', '0', '0', 'admin', '1');
INSERT INTO factura_vta VALUES('00000062', '20090226', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000010', '20090226', '', '', '', '1', '2', '5', '33', '1', '1', '00000000', 'B', '0001', '1', '1', '0', '0', '0', '0', 'admin', '1');
INSERT INTO factura_vta VALUES('00000011', '20090226', '', '', '', '1', '2', '5', '33', '1', '1', '00000000', 'B', '0001', '1', '1', '0', '0', '0', '0', 'admin', '1');
INSERT INTO factura_vta VALUES('00000063', '20090226', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000012', '20090226', '', '', '', '1', '2', '5', '33', '1', '1', '00000000', 'B', '0001', '1', '1', '0', '0', '0', '0', 'admin', '1');
INSERT INTO factura_vta VALUES('00000013', '20090226', '', '', '', '1', '2', '5', '33', '1', '1', '00000000', 'B', '0001', '1', '1', '0', '0', '0', '0', 'admin', '1');
INSERT INTO factura_vta VALUES('00000064', '20090226', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000065', '20090226', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000066', '20090226', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000014', '20090226', '', '', '', '1', '2', '5', '33', '1', '1', '00000000', 'B', '0001', '1', '1', '0', '0', '0', '0', 'admin', '1');
INSERT INTO factura_vta VALUES('00000067', '20090226', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000068', '20090226', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000069', '20090226', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000070', '20090226', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000071', '20090226', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000072', '20090226', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000073', '20090226', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000074', '20090227', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000075', '20090227', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000015', '20090227', '', '', '', '1', '2', '5', '33', '1', '1', '00000000', 'B', '0001', '1', '1', '0', '0', '0', '0', 'admin', '1');
INSERT INTO factura_vta VALUES('00000016', '20090227', '', '', '', '1', '2', '5', '33', '1', '1', '00000000', 'B', '0001', '1', '1', '0', '0', '0', '0', 'admin', '1');
INSERT INTO factura_vta VALUES('00000017', '20090227', '', '', '', '1', '2', '5', '33', '1', '1', '00000000', 'B', '0001', '1', '1', '0', '0', '0', '0', 'admin', '1');
INSERT INTO factura_vta VALUES('00000018', '20090227', '', '', '', '1', '2', '5', '33', '1', '1', '00000000', 'B', '0001', '1', '1', '0', '0', '0', '0', 'admin', '1');
INSERT INTO factura_vta VALUES('00000019', '20090227', '', '', '', '1', '2', '5', '33', '1', '1', '00000000', 'B', '0001', '1', '1', '0', '0', '0', '0', 'admin', '1');
INSERT INTO factura_vta VALUES('00000076', '20090305', '', '', 'N/C', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000020', '20090305', '', '', 'N/C', '1', '2', '5', '33', '1', '1', '00000000', 'B', '0001', '1', '1', '0', '0', '0', '0', 'admin', '1');
INSERT INTO factura_vta VALUES('00000077', '20090305', '', '', '', '1', '1', '5', '33', '1', '1', '00000001', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000078', '20090305', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000079', '20090306', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000021', '20090306', '', '', '', '1', '2', '5', '33', '1', '1', '00000000', 'B', '0001', '1', '1', '0', '0', '0', '0', 'admin', '1');
INSERT INTO factura_vta VALUES('00000080', '20090306', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000022', '20090306', '', '', '', '1', '2', '5', '33', '1', '1', '00000000', 'B', '0001', '1', '1', '0', '0', '0', '0', 'admin', '1');
INSERT INTO factura_vta VALUES('00000081', '20090309', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000082', '20090309', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000083', '20090309', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000084', '20090309', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000085', '20090309', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000086', '20090325', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
INSERT INTO factura_vta VALUES('00000087', '20090326', '', '', '', '1', '1', '5', '33', '1', '1', '00000000', 'A', '0001', '1', '1', '0', '0', '0', '0', 'admin', '3');
UNLOCK TABLES;


--
-- Table structure for table `factura_vta_detalle`
--

DROP TABLE IF EXISTS factura_vta_detalle;
CREATE TABLE `factura_vta_detalle` (
  `n_factura` int(8) unsigned zerofill default NULL,
  `cod_prod` int(11) default NULL,
  `cod_variedad` int(11) default NULL,
  `cod_marca` int(11) default NULL,
  `cod_grupo` int(11) default NULL,
  `cantidad` float NOT NULL,
  `precio` float NOT NULL,
  `bonificacion` float default NULL,
  `cod_talonario` char(1) default NULL,
  `num_talonario` int(4) unsigned zerofill default NULL,
  `iva` float NOT NULL,
  KEY `Reffactura_vta26` (`n_factura`,`cod_talonario`,`num_talonario`),
  KEY `Refproducto27` (`cod_prod`,`cod_variedad`,`cod_marca`,`cod_grupo`),
  KEY `Ref2726` (`n_factura`,`num_talonario`,`cod_talonario`),
  KEY `Ref127` (`cod_marca`,`cod_prod`,`cod_grupo`,`cod_variedad`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `factura_vta_detalle`
--

LOCK TABLES factura_vta_detalle WRITE;
INSERT INTO factura_vta_detalle VALUES('00000001', '1', '1', '1', '1', '3', '21.35', '3', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000001', '1', '2', '1', '1', '10', '20.22', '2', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000001', '1', '1', '2', '1', '5', '21.36', '4.5', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000001', '1', '1', '1', '3', '75', '12', '3', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000001', '1', '1', '2', '3', '6', '10', '4.5', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000002', '1', '1', '1', '5', '10', '6', '5', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000002', '1', '1', '2', '5', '30', '6', '3', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000002', '1', '1', '1', '1', '10', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000002', '1', '2', '1', '1', '10', '20.22', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000002', '1', '1', '2', '1', '10', '21.36', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000002', '1', '2', '2', '1', '10', '61.01', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000002', '1', '1', '1', '3', '10', '12', '6', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000003', '1', '1', '1', '5', '100', '6', '10', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000004', '2', '1', '1', '5', '1', '800', '0', 'A', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000003', '1', '1', '1', '1', '1', '21.35', '0', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000003', '2', '1', '1', '5', '1', '800', '0', 'B', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000005', '1', '1', '1', '1', '3', '21.35', '5', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000005', '1', '1', '2', '1', '5', '21.36', '1', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000005', '1', '1', '1', '2', '2', '28.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000005', '2', '1', '1', '5', '1', '800', '0', 'A', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000006', '1', '1', '1', '1', '5', '21.35', '5', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000006', '1', '1', '2', '1', '6', '21.36', '2', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000006', '1', '1', '2', '1', '6', '21.36', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000006', '2', '1', '1', '5', '1', '800', '0', 'A', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000007', '1', '1', '1', '1', '4', '21.35', '25', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000007', '2', '1', '1', '5', '1', '800', '4', 'A', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000008', '1', '1', '1', '1', '5', '21.35', '3', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000008', '2', '1', '1', '5', '1', '800', '30', 'A', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000008', '1', '1', '2', '1', '6', '21.36', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000009', '1', '1', '1', '1', '10', '21.35', '2', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000009', '1', '1', '2', '1', '2', '21.36', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000004', '1', '1', '1', '1', '10', '21.35', '0', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000010', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000005', '1', '1', '1', '1', '10', '21.35', '6', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000011', '1', '1', '1', '1', '10', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000012', '1', '1', '1', '1', '10', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000013', '1', '1', '1', '1', '10', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000014', '1', '1', '1', '1', '10', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000015', '1', '1', '1', '1', '10', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000016', '1', '1', '1', '1', '10', '21.35', '1', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000017', '1', '1', '1', '1', '10', '21.35', '2', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000018', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000019', '1', '1', '1', '1', '10', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000020', '1', '1', '1', '1', '10', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000021', '1', '1', '1', '1', '10', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000022', '1', '1', '1', '2', '10', '28.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000023', '1', '1', '1', '1', '10', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000024', '1', '1', '1', '1', '10', '21.35', '2', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000025', '1', '1', '1', '1', '10', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000026', '1', '1', '1', '1', '10', '21.35', '2', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000027', '1', '1', '2', '1', '100', '21.36', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000028', '1', '1', '1', '1', '10', '21.35', '1', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000029', '1', '1', '1', '1', '10', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000029', '1', '1', '1', '2', '5', '28.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000029', '1', '1', '2', '1', '3', '21.36', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000030', '1', '1', '1', '1', '10', '21.35', '5', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000030', '1', '1', '2', '1', '2', '21.36', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000030', '1', '1', '1', '2', '3', '28.35', '2', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000030', '1', '1', '1', '3', '5', '12', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000030', '1', '1', '2', '4', '4', '19', '3', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000030', '1', '1', '1', '5', '9', '6', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000006', '1', '1', '1', '1', '10', '21.35', '5', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000006', '1', '1', '2', '1', '2', '21.36', '0', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000006', '1', '1', '1', '2', '3', '28.35', '2', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000006', '1', '1', '1', '3', '5', '12', '0', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000006', '1', '1', '2', '4', '4', '19', '3', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000006', '1', '1', '1', '5', '9', '6', '0', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000031', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000031', '2', '1', '1', '5', '1', '800', '0', 'A', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000007', '1', '1', '1', '1', '1', '21.35', '0', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000007', '2', '1', '1', '5', '1', '800', '0', 'B', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000032', '1', '1', '1', '1', '10', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000032', '1', '1', '2', '1', '10', '21.36', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000033', '1', '1', '1', '1', '10', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000033', '1', '1', '2', '1', '2', '21.36', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000033', '1', '1', '1', '2', '3', '28.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000033', '1', '1', '1', '5', '1', '6', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000034', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000035', '1', '1', '1', '1', '1', '21.35', '10', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000035', '1', '1', '2', '1', '5', '21.36', '2', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000035', '1', '1', '1', '2', '10', '28.35', '3', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000035', '1', '1', '1', '3', '10', '12', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000035', '1', '1', '1', '4', '10', '9', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000008', '1', '1', '1', '4', '10', '9', '0', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000008', '1', '1', '2', '3', '5', '10', '0', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000008', '1', '1', '1', '4', '10', '9', '0', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000008', '1', '1', '1', '1', '20', '21.35', '5', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000036', '1', '1', '1', '1', '10', '21.35', '5', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000036', '1', '2', '2', '1', '20', '61.01', '5', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000036', '1', '1', '1', '5', '3', '6', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000036', '1', '1', '1', '3', '10', '12', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000037', '1', '1', '1', '1', '10', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000037', '1', '2', '1', '1', '5', '20.22', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000037', '1', '1', '1', '2', '3', '28.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000037', '1', '1', '1', '5', '3', '6', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000038', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000038', '2', '1', '1', '5', '1', '800', '0', 'A', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000039', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000040', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000040', '2', '1', '1', '5', '1', '800', '0', 'A', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000041', '1', '1', '1', '1', '1', '21.35', '2', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000041', '1', '1', '2', '1', '2', '21.36', '1', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000042', '1', '1', '1', '1', '10', '21.35', '2', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000042', '1', '1', '1', '2', '1', '28.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000042', '1', '1', '1', '3', '1', '12', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000043', '1', '1', '1', '1', '1', '21.35', '1', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000043', '1', '1', '1', '2', '1', '28.35', '1', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000044', '1', '1', '1', '1', '1', '21.35', '1', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000044', '1', '1', '1', '2', '1', '28.35', '1', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000045', '1', '1', '1', '1', '10', '21.35', '5', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000045', '1', '1', '1', '2', '20', '28.35', '6', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000046', '1', '1', '1', '1', '10', '21.35', '5', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000046', '1', '1', '1', '2', '20', '28.35', '6', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000047', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000047', '1', '1', '1', '2', '1', '28.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000048', '1', '1', '1', '1', '10', '21.35', '1', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000048', '1', '1', '1', '2', '20', '28.35', '2', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000048', '1', '1', '1', '3', '3', '12', '4', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000049', '1', '1', '1', '1', '200', '21.35', '4', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000049', '1', '1', '1', '3', '200', '12', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000049', '1', '1', '1', '2', '100', '28.35', '5', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000050', '1', '1', '1', '1', '12', '21.35', '3', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000050', '1', '2', '1', '1', '25', '20.22', '5', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000051', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000052', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000053', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000054', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000055', '2', '1', '1', '5', '10', '800', '0', 'A', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000056', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000056', '2', '1', '1', '5', '1', '800', '0', 'A', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000057', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000057', '2', '1', '1', '5', '1', '800', '0', 'A', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000058', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000058', '2', '1', '1', '5', '1', '800', '0', 'A', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000059', '1', '1', '1', '1', '10', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000059', '1', '1', '2', '1', '3', '21.36', '2', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000059', '2', '1', '1', '5', '2', '800', '0', 'A', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000059', '1', '1', '1', '3', '4', '12', '4', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000060', '1', '1', '1', '1', '10', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000060', '1', '1', '2', '1', '3', '21.36', '2', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000060', '2', '1', '1', '5', '2', '800', '0', 'A', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000060', '1', '1', '1', '3', '4', '12', '4', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000061', '1', '1', '1', '1', '1', '21.35', '1', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000061', '1', '1', '2', '1', '1', '21.36', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000009', '1', '1', '1', '1', '1', '21.35', '1', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000009', '1', '1', '2', '1', '1', '21.36', '0', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000062', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000062', '1', '1', '2', '1', '1', '21.36', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000010', '1', '1', '1', '1', '1', '21.35', '1', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000010', '1', '1', '2', '1', '1', '21.36', '0', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000011', '1', '1', '1', '1', '1', '21.35', '1', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000011', '1', '1', '2', '1', '1', '21.36', '0', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000063', '1', '1', '1', '1', '1', '21.35', '1', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000063', '1', '1', '2', '1', '1', '21.36', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000012', '1', '1', '1', '1', '1', '21.35', '1', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000012', '1', '1', '2', '1', '1', '21.36', '0', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000013', '1', '1', '1', '1', '1', '21.35', '1', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000013', '1', '1', '2', '1', '1', '21.36', '0', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000064', '1', '1', '1', '1', '1', '21.35', '1', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000064', '1', '1', '2', '1', '1', '21.36', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000065', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000066', '1', '1', '1', '1', '10', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000066', '1', '1', '2', '1', '3', '21.36', '2', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000066', '2', '1', '1', '5', '2', '800', '0', 'A', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000066', '1', '1', '1', '3', '4', '12', '4', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000014', '1', '1', '1', '1', '10', '21.35', '0', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000014', '1', '1', '2', '1', '3', '21.36', '2', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000014', '2', '1', '1', '5', '2', '800', '0', 'B', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000014', '1', '1', '1', '3', '4', '12', '4', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000067', '1', '1', '1', '1', '20', '21.35', '5', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000067', '1', '1', '2', '1', '3', '21.36', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000067', '1', '1', '1', '2', '4', '28.35', '5', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000067', '2', '1', '1', '5', '2', '800', '0', 'A', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000068', '2', '1', '1', '5', '2', '800', '0', 'A', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000069', '2', '1', '1', '5', '2', '800', '0', 'A', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000070', '1', '1', '1', '1', '1', '21.35', '2', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000070', '1', '1', '2', '1', '3', '21.36', '4', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000070', '1', '1', '1', '3', '1', '12', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000070', '1', '1', '1', '4', '6', '9', '2', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000070', '1', '1', '1', '5', '1', '6', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000070', '2', '1', '1', '5', '1', '800', '0', 'A', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000071', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000072', '1', '1', '1', '1', '1', '21.35', '1', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000073', '1', '1', '1', '1', '1', '21.35', '3', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000073', '1', '1', '2', '1', '2', '21.36', '3', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000074', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000074', '1', '1', '2', '1', '1', '21.36', '1', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000075', '2', '1', '1', '5', '2', '800', '5', 'A', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000075', '1', '1', '1', '4', '10', '9', '6', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000015', '1', '1', '1', '1', '1', '21.35', '0', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000016', '1', '1', '1', '1', '10', '21.35', '0', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000016', '1', '1', '2', '1', '8', '21.36', '0', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000017', '1', '1', '1', '1', '1', '21.35', '0', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000018', '1', '1', '1', '1', '10', '21.35', '0', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000019', '2', '1', '1', '5', '20', '800', '0', 'B', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000076', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000020', '1', '1', '2', '1', '20', '21.36', '1', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000077', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000077', '2', '1', '1', '5', '1', '800', '0', 'A', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000078', '1', '1', '1', '1', '10', '21.35', '1', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000079', '1', '1', '1', '1', '1', '21.35', '1', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000021', '1', '1', '1', '1', '1', '21.35', '1', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000080', '1', '1', '1', '1', '1', '21.35', '1', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000022', '1', '1', '1', '1', '1', '21.35', '0', 'B', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000081', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000082', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000083', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000084', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000085', '2', '1', '1', '5', '1', '800', '0', 'A', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000086', '1', '1', '1', '1', '10', '21.35', '2', 'A', '0001', '21');
INSERT INTO factura_vta_detalle VALUES('00000086', '1', '2', '1', '1', '20', '20.22', '3', 'A', '0001', '10.5');
INSERT INTO factura_vta_detalle VALUES('00000087', '1', '1', '1', '1', '1', '21.35', '0', 'A', '0001', '21');
UNLOCK TABLES;


--
-- Table structure for table `factura_vta_no_cliente`
--

DROP TABLE IF EXISTS factura_vta_no_cliente;
CREATE TABLE `factura_vta_no_cliente` (
  `n_factura` int(8) unsigned zerofill NOT NULL,
  `fecha` int(11) NOT NULL,
  `hora_entrega` text,
  `lugar` text,
  `observacion` text,
  `razon_social` text NOT NULL,
  `cod_zona` int(11) default NULL,
  `direccion` text NOT NULL,
  `localidad` text NOT NULL,
  `provincia` text,
  `cond_iva` text,
  `cuit` varchar(11) default NULL,
  `cod_categoria` int(11) default NULL,
  `cod_vendedor` int(11) default NULL,
  `cod_repartidor` int(11) default NULL,
  `cod_talonario` char(1) NOT NULL,
  `num_talonario` int(4) unsigned zerofill NOT NULL,
  `num_remito` int(11) NOT NULL,
  `iva` float default NULL,
  `imp_interno` float default NULL,
  `perc_iva` float default NULL,
  `ing_bruto` float default NULL,
  `usuario` text,
  `cod_fp` int(11) NOT NULL,
  PRIMARY KEY  (`n_factura`,`cod_talonario`,`num_talonario`),
  KEY `Reftalonario124` (`cod_talonario`,`num_talonario`),
  KEY `Ref26114` (`cod_fp`),
  KEY `Ref22124` (`num_talonario`,`cod_talonario`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `factura_vta_no_cliente`
--

LOCK TABLES factura_vta_no_cliente WRITE;
UNLOCK TABLES;


--
-- Table structure for table `factura_vta_no_cliente_detalle`
--

DROP TABLE IF EXISTS factura_vta_no_cliente_detalle;
CREATE TABLE `factura_vta_no_cliente_detalle` (
  `n_factura` int(8) unsigned zerofill default NULL,
  `cod_prod` int(11) default NULL,
  `cod_variedad` int(11) default NULL,
  `cod_marca` int(11) default NULL,
  `cod_grupo` int(11) default NULL,
  `cantidad` float NOT NULL,
  `precio` float NOT NULL,
  `bonificacion` float default NULL,
  `cod_talonario` char(1) default NULL,
  `num_talonario` int(4) unsigned zerofill default NULL,
  `iva` float NOT NULL,
  KEY `Reffactura_vta_no_cliente111` (`n_factura`,`cod_talonario`,`num_talonario`),
  KEY `Refproducto112` (`cod_prod`,`cod_variedad`,`cod_marca`,`cod_grupo`),
  KEY `Ref53111` (`n_factura`,`num_talonario`,`cod_talonario`),
  KEY `Ref1112` (`cod_marca`,`cod_prod`,`cod_grupo`,`cod_variedad`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `factura_vta_no_cliente_detalle`
--

LOCK TABLES factura_vta_no_cliente_detalle WRITE;
UNLOCK TABLES;


--
-- Table structure for table `factura_vta_tmp`
--

DROP TABLE IF EXISTS factura_vta_tmp;
CREATE TABLE `factura_vta_tmp` (
  `usuario` text,
  `cod_prod` int(11) default NULL,
  `descripcion` text,
  `cantidad` float NOT NULL,
  `precio` float NOT NULL,
  `bonificacion` float default NULL,
  `importe` float default NULL,
  `linea` int(11) default NULL,
  `iva` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `factura_vta_tmp`
--

LOCK TABLES factura_vta_tmp WRITE;
UNLOCK TABLES;


--
-- Table structure for table `fletero`
--

DROP TABLE IF EXISTS fletero;
CREATE TABLE `fletero` (
  `cod_flero` int(11) NOT NULL,
  `dni` int(11) NOT NULL,
  `nombre` text NOT NULL,
  `domicilio` text,
  `tel` text,
  `cuit` text,
  `cod_localidad` int(11) NOT NULL,
  `cod_prov` int(11) NOT NULL,
  `cod_pais` int(11) NOT NULL,
  `cod_iva` int(11) NOT NULL,
  `cod_talonario` char(1) NOT NULL,
  PRIMARY KEY  (`cod_flero`),
  KEY `Ref1716` (`cod_prov`,`cod_localidad`,`cod_pais`),
  KEY `Ref2864` (`cod_talonario`,`cod_iva`),
  KEY `Reflocalidad16` (`cod_localidad`,`cod_prov`,`cod_pais`),
  KEY `Refiva64` (`cod_iva`,`cod_talonario`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fletero`
--

LOCK TABLES fletero WRITE;
INSERT INTO fletero VALUES('1', '0', 'LUIS ', 'Bº ANDRESITO ', '03758-15456515', '', '33', '1', '1', '4', 'B');
INSERT INTO fletero VALUES('2', '1', 'SEVERO ANTUNEZ', 'B. IRIGOYEN', '1', '', '33', '1', '1', '4', 'B');
INSERT INTO fletero VALUES('3', '11', 'NEVES ', 'APOSTOLES', '15456630', '', '33', '1', '1', '4', 'B');
INSERT INTO fletero VALUES('4', '1111', 'IBARRA MAURICIO', 'APOSTOLES', '15408158', '', '33', '1', '1', '4', 'B');
INSERT INTO fletero VALUES('6', '111111', 'PEDRO KLEVET', 'BARRIO ILLIA MAZ 9 CASA8', '15451240', '', '33', '1', '1', '4', 'B');
INSERT INTO fletero VALUES('5', '33333333', 'MULA', 'A', '1', '', '33', '1', '1', '4', 'B');
INSERT INTO fletero VALUES('7', '121211', 'JAVIER', 'BARRIO IRIGOYEN', '11111', '', '33', '1', '1', '4', 'B');
INSERT INTO fletero VALUES('8', '11111', 'DURE DAMIAN JAVIER', 'APOSTOLES', '15408143', '', '33', '1', '1', '4', 'B');
INSERT INTO fletero VALUES('20', '11111111', 'DEPOSITO', 'RUTA 201 - KM 40', '3758-424181', '', '33', '1', '1', '4', 'B');
INSERT INTO fletero VALUES('9', '66666', 'NEVES', 'APOSTOLES', '15456630', '', '25', '2', '1', '4', 'B');
INSERT INTO fletero VALUES('10', '77777', 'NEVES', 'APOSTOLES', '15456630', '', '47', '2', '1', '4', 'B');
INSERT INTO fletero VALUES('11', '8888', 'NEVES', 'APOSTOLES', '15456630', '', '24', '2', '1', '4', 'B');
INSERT INTO fletero VALUES('12', '12', 'LUIS', 'APOSTOLES', '03758-15456515', '', '33', '1', '1', '4', 'B');
INSERT INTO fletero VALUES('13', '13', 'PEDRO', 'APOSTOLES', '0375815451240', '', '33', '1', '1', '4', 'B');
INSERT INTO fletero VALUES('14', '14', 'IBARRA MAURICIO', 'APOSTOLES', '15408168', '', '27', '1', '1', '4', 'B');
INSERT INTO fletero VALUES('21', '21', 'VENTA DE DEPOSITO', 'RUTA 201 - KM 40', '424181', '', '33', '1', '1', '4', 'B');
INSERT INTO fletero VALUES('19', '19', 'VENTA EN DEPOSITO', 'RTA.201 KM 2', '424181', '', '33', '1', '1', '4', 'B');
INSERT INTO fletero VALUES('15', '15', 'LUIS', 'APOSTOLES', '03758-15456515', '', '33', '1', '1', '6', 'X');
INSERT INTO fletero VALUES('16', '16', 'SUBRESKI', 'APOSTOLES', '03758-15438088', '', '33', '1', '1', '6', 'X');
INSERT INTO fletero VALUES('17', '17', 'IBARRA', 'XXXX', '1111111', '', '49', '1', '1', '6', 'X');
INSERT INTO fletero VALUES('18', '18', 'SUBRESKI MOISES', 'B. ESTACION ', '3758-438088', '', '33', '1', '1', '6', 'X');
UNLOCK TABLES;


--
-- Table structure for table `fletero_por_vehiculo`
--

DROP TABLE IF EXISTS fletero_por_vehiculo;
CREATE TABLE `fletero_por_vehiculo` (
  `cod_flero` int(11) NOT NULL,
  `cod_vehiculo` int(11) NOT NULL,
  PRIMARY KEY  (`cod_flero`,`cod_vehiculo`),
  KEY `Ref617` (`cod_flero`),
  KEY `Ref718` (`cod_vehiculo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fletero_por_vehiculo`
--

LOCK TABLES fletero_por_vehiculo WRITE;
INSERT INTO fletero_por_vehiculo VALUES('1', '1');
INSERT INTO fletero_por_vehiculo VALUES('2', '2');
INSERT INTO fletero_por_vehiculo VALUES('3', '3');
INSERT INTO fletero_por_vehiculo VALUES('4', '4');
INSERT INTO fletero_por_vehiculo VALUES('5', '7');
INSERT INTO fletero_por_vehiculo VALUES('6', '6');
INSERT INTO fletero_por_vehiculo VALUES('7', '5');
INSERT INTO fletero_por_vehiculo VALUES('8', '8');
INSERT INTO fletero_por_vehiculo VALUES('9', '9');
INSERT INTO fletero_por_vehiculo VALUES('10', '9');
INSERT INTO fletero_por_vehiculo VALUES('11', '9');
INSERT INTO fletero_por_vehiculo VALUES('12', '1');
INSERT INTO fletero_por_vehiculo VALUES('13', '6');
INSERT INTO fletero_por_vehiculo VALUES('14', '4');
INSERT INTO fletero_por_vehiculo VALUES('15', '1');
INSERT INTO fletero_por_vehiculo VALUES('16', '21');
INSERT INTO fletero_por_vehiculo VALUES('17', '6');
INSERT INTO fletero_por_vehiculo VALUES('18', '21');
INSERT INTO fletero_por_vehiculo VALUES('19', '21');
INSERT INTO fletero_por_vehiculo VALUES('20', '20');
INSERT INTO fletero_por_vehiculo VALUES('21', '21');
UNLOCK TABLES;


--
-- Table structure for table `forma_pago`
--

DROP TABLE IF EXISTS forma_pago;
CREATE TABLE `forma_pago` (
  `cod_fp` int(11) NOT NULL auto_increment,
  `descripcion` text NOT NULL,
  `observacion` text,
  PRIMARY KEY  (`cod_fp`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forma_pago`
--

LOCK TABLES forma_pago WRITE;
INSERT INTO forma_pago VALUES('1', 'CONTADO', 'PAGO CONTADO EFECTIVO');
INSERT INTO forma_pago VALUES('2', 'CTA CTE', 'CUENTA CORRIENTE');
INSERT INTO forma_pago VALUES('3', 'CTA CTE 7 DIAS', '');
UNLOCK TABLES;


--
-- Table structure for table `gastos`
--

DROP TABLE IF EXISTS gastos;
CREATE TABLE `gastos` (
  `id` int(11) NOT NULL auto_increment,
  `fecha` int(11) NOT NULL,
  `hora` varchar(20) NOT NULL,
  `descripcion` text NOT NULL,
  `importe` float NOT NULL,
  `iva` float default NULL,
  `otros_impuestos` float default NULL,
  `total` char(10) default NULL,
  `observacion` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gastos`
--

LOCK TABLES gastos WRITE;
INSERT INTO gastos VALUES('1', '20090101', '12', 'DASD', '10', '2', '1', '13', 'DFDSFD');
INSERT INTO gastos VALUES('2', '20090102', '13', 'MADERA', '100', '21', '10', '131', 'PARA PUERTA');
UNLOCK TABLES;


--
-- Table structure for table `grupo`
--

DROP TABLE IF EXISTS grupo;
CREATE TABLE `grupo` (
  `cod_grupo` int(11) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY  (`cod_grupo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `grupo`
--

LOCK TABLES grupo WRITE;
INSERT INTO grupo VALUES('1', 'DISCO RIGIDO');
INSERT INTO grupo VALUES('2', 'PLACA MADRE');
INSERT INTO grupo VALUES('4', 'PROCESADORES');
INSERT INTO grupo VALUES('3', 'MONITORES');
INSERT INTO grupo VALUES('5', 'IMPRESORAS');
INSERT INTO grupo VALUES('6', 'TECLADOS');
INSERT INTO grupo VALUES('7', 'MOUSE');
INSERT INTO grupo VALUES('8', 'PARLANTES');
INSERT INTO grupo VALUES('9', 'OTROS');
INSERT INTO grupo VALUES('10', 'PENDRIVE');
INSERT INTO grupo VALUES('11', 'JOYSTICK');
INSERT INTO grupo VALUES('12', 'WEBCAM');
UNLOCK TABLES;


--
-- Table structure for table `imp_interno`
--

DROP TABLE IF EXISTS imp_interno;
CREATE TABLE `imp_interno` (
  `cod_imp_interno` int(11) NOT NULL auto_increment,
  `nombre` text,
  `tasa` float NOT NULL,
  PRIMARY KEY  (`cod_imp_interno`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `imp_interno`
--

LOCK TABLES imp_interno WRITE;
INSERT INTO imp_interno VALUES('1', 'IMPUESTO INTERNO', '0');
UNLOCK TABLES;


--
-- Table structure for table `ing_bruto`
--

DROP TABLE IF EXISTS ing_bruto;
CREATE TABLE `ing_bruto` (
  `cod_ing_bruto` int(11) NOT NULL auto_increment,
  `nombre` text,
  `tasa` float NOT NULL,
  `cod_prov` int(11) NOT NULL,
  `cod_pais` int(11) NOT NULL,
  PRIMARY KEY  (`cod_ing_bruto`),
  KEY `Refprovincia133` (`cod_prov`,`cod_pais`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ing_bruto`
--

LOCK TABLES ing_bruto WRITE;
UNLOCK TABLES;


--
-- Table structure for table `iva`
--

DROP TABLE IF EXISTS iva;
CREATE TABLE `iva` (
  `cod_iva` int(11) NOT NULL,
  `cod_talonario` char(1) NOT NULL,
  `nombre` text NOT NULL,
  `cuit` char(1) default NULL,
  PRIMARY KEY  (`cod_iva`,`cod_talonario`),
  KEY `Ref2598` (`cod_talonario`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `iva`
--

LOCK TABLES iva WRITE;
INSERT INTO iva VALUES('6', 'B', 'CONSUMIDOR FINAL', 'N');
INSERT INTO iva VALUES('1', 'A', 'RESP. INSCRIPTO', 'S');
INSERT INTO iva VALUES('2', 'B', 'RESP. MONOTRIBUTO', 'N');
UNLOCK TABLES;


--
-- Table structure for table `localidad`
--

DROP TABLE IF EXISTS localidad;
CREATE TABLE `localidad` (
  `cod_localidad` int(11) NOT NULL auto_increment,
  `cod_prov` int(11) NOT NULL,
  `cod_pais` int(11) NOT NULL,
  `nombre` text NOT NULL,
  `cp` int(11) default NULL,
  PRIMARY KEY  (`cod_localidad`,`cod_prov`,`cod_pais`),
  KEY `Ref1912` (`cod_pais`,`cod_prov`),
  KEY `Refprovincia12` (`cod_prov`,`cod_pais`)
) ENGINE=MyISAM AUTO_INCREMENT=67 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `localidad`
--

LOCK TABLES localidad WRITE;
INSERT INTO localidad VALUES('5', '1', '1', 'CERRO AZUL', '3313');
INSERT INTO localidad VALUES('6', '1', '1', 'L.N ALEM', '3315');
INSERT INTO localidad VALUES('7', '1', '1', 'DOS DE MAYO', '3364');
INSERT INTO localidad VALUES('8', '1', '1', 'SAN VICENTE', '3364');
INSERT INTO localidad VALUES('9', '1', '1', 'A. DEL VALLE', '3364');
INSERT INTO localidad VALUES('10', '1', '1', 'CAM.GRANDE', '3362');
INSERT INTO localidad VALUES('11', '1', '1', 'EL SOBERBIO', '3364');
INSERT INTO localidad VALUES('12', '1', '1', 'CAMPO VIERA', '3362');
INSERT INTO localidad VALUES('13', '1', '1', 'CAM.RAMON', '3361');
INSERT INTO localidad VALUES('14', '1', '1', 'VILLA BONITA', '3361');
INSERT INTO localidad VALUES('16', '1', '1', 'CNIA ACARAGUATAY', '3386');
INSERT INTO localidad VALUES('17', '1', '1', 'S.FRANCISO DE ASIS', '3363');
INSERT INTO localidad VALUES('18', '1', '1', 'PANAMBI', '3361');
INSERT INTO localidad VALUES('19', '1', '1', '9JULIO-A. POSSE, D.25 MAYO-', '3363');
INSERT INTO localidad VALUES('20', '1', '1', 'SANTA RITA', '3363');
INSERT INTO localidad VALUES('21', '1', '1', 'ALBA POSSE', '3363');
INSERT INTO localidad VALUES('22', '1', '1', 'CNIA 25 DE MAYO', '3363');
INSERT INTO localidad VALUES('23', '1', '1', 'OBERA', '3360');
INSERT INTO localidad VALUES('24', '2', '1', 'SANTO TOME', '3340');
INSERT INTO localidad VALUES('25', '2', '1', 'ALVEAR', '3344');
INSERT INTO localidad VALUES('26', '2', '1', 'VIRASORO', '3342');
INSERT INTO localidad VALUES('27', '1', '1', 'SAN JAVIER', '3357');
INSERT INTO localidad VALUES('28', '1', '1', 'AZARA', '3351');
INSERT INTO localidad VALUES('29', '2', '1', 'GARRUCHOS', '3351');
INSERT INTO localidad VALUES('30', '1', '1', 'SAN JOSE', '3306');
INSERT INTO localidad VALUES('31', '2', '1', 'SAN CARLOS', '3306');
INSERT INTO localidad VALUES('32', '2', '1', 'GARABI', '3342');
INSERT INTO localidad VALUES('33', '1', '1', 'APOSTOLES', '3350');
INSERT INTO localidad VALUES('34', '2', '1', 'COL. LIEBIG', '3351');
INSERT INTO localidad VALUES('35', '1', '1', 'C. DE LA SIERRA', '3355');
INSERT INTO localidad VALUES('36', '2', '1', 'ITUZAINGO', '3360');
INSERT INTO localidad VALUES('37', '5', '1', 'CALCHINES', '1111');
INSERT INTO localidad VALUES('38', '5', '1', 'STA. FE', '3000');
INSERT INTO localidad VALUES('39', '1', '1', 'POSADAS', '3300');
INSERT INTO localidad VALUES('40', '3', '1', 'SAENZ PENA', '1');
INSERT INTO localidad VALUES('41', '3', '1', 'PARANA', '3100');
INSERT INTO localidad VALUES('42', '3', '1', 'ENTRE RIOS', '3100');
INSERT INTO localidad VALUES('43', '4', '1', 'CHASCOMUS', '7130');
INSERT INTO localidad VALUES('44', '4', '1', 'BELLA VISTA', '1661');
INSERT INTO localidad VALUES('45', '1', '1', 'ITACARUARE', '3353');
INSERT INTO localidad VALUES('46', '1', '1', 'S.ENCANTADO', '3364');
INSERT INTO localidad VALUES('47', '2', '1', 'LA CRUZ', '3346');
INSERT INTO localidad VALUES('48', '1', '1', 'SAN ANTONIO', '3366');
INSERT INTO localidad VALUES('49', '1', '1', 'GOB. LOPEZ', '1111');
INSERT INTO localidad VALUES('50', '1', '1', '2 ARROYOS', '1111');
INSERT INTO localidad VALUES('51', '1', '1', 'LA CORITA', '1111');
INSERT INTO localidad VALUES('52', '1', '1', 'COLONIA GUARANI', '3309');
INSERT INTO localidad VALUES('53', '1', '1', 'PARAJE LIBERTAD', '3363');
INSERT INTO localidad VALUES('54', '1', '1', 'PICADA YEPOYA', '3361');
INSERT INTO localidad VALUES('55', '4', '1', 'CAPITAL FEDERAL', '1112');
INSERT INTO localidad VALUES('56', '4', '1', 'SAN JUSTO', '1754');
INSERT INTO localidad VALUES('57', '3', '1', 'FEDERACION', '1');
INSERT INTO localidad VALUES('58', '2', '1', 'LIEBIG', '1');
INSERT INTO localidad VALUES('59', '1', '1', '3 CAPONES', '3353');
INSERT INTO localidad VALUES('60', '2', '1', 'YAPEYU', '1111');
INSERT INTO localidad VALUES('61', '2', '1', 'GUAVIRAVI', '1111');
INSERT INTO localidad VALUES('62', '3', '1', 'VALLE MARIA', '3101');
INSERT INTO localidad VALUES('63', '5', '1', 'FUNES', '2132');
INSERT INTO localidad VALUES('64', '3', '1', 'CHAJARI', '3228');
INSERT INTO localidad VALUES('65', '2', '1', 'CORRIENTES', '3400');
INSERT INTO localidad VALUES('66', '4', '1', 'LLAVALLOL', '1836');
UNLOCK TABLES;


--
-- Table structure for table `marca`
--

DROP TABLE IF EXISTS marca;
CREATE TABLE `marca` (
  `cod_marca` int(11) NOT NULL,
  `cod_grupo` int(11) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY  (`cod_marca`,`cod_grupo`),
  KEY `Ref1319` (`cod_grupo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `marca`
--

LOCK TABLES marca WRITE;
INSERT INTO marca VALUES('1', '1', 'SAMSUNG');
INSERT INTO marca VALUES('2', '1', 'SEAGATE');
INSERT INTO marca VALUES('1', '2', 'ASUS');
INSERT INTO marca VALUES('2', '2', 'GIGABYTE');
INSERT INTO marca VALUES('1', '3', 'WIESONIC');
INSERT INTO marca VALUES('2', '3', 'SAMSUNG');
INSERT INTO marca VALUES('1', '4', 'INTEL');
INSERT INTO marca VALUES('2', '4', 'AMD');
INSERT INTO marca VALUES('1', '5', 'EPSON');
INSERT INTO marca VALUES('2', '5', 'HP');
UNLOCK TABLES;


--
-- Table structure for table `medida`
--

DROP TABLE IF EXISTS medida;
CREATE TABLE `medida` (
  `cod_medida` int(11) NOT NULL auto_increment,
  `unidad_de_medida` text NOT NULL,
  PRIMARY KEY  (`cod_medida`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medida`
--

LOCK TABLES medida WRITE;
INSERT INTO medida VALUES('1', 'CM3');
UNLOCK TABLES;


--
-- Table structure for table `pais`
--

DROP TABLE IF EXISTS pais;
CREATE TABLE `pais` (
  `cod_pais` int(11) NOT NULL auto_increment,
  `nombre` text NOT NULL,
  PRIMARY KEY  (`cod_pais`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pais`
--

LOCK TABLES pais WRITE;
INSERT INTO pais VALUES('1', 'ARGENTINA');
UNLOCK TABLES;


--
-- Table structure for table `pedidos`
--

DROP TABLE IF EXISTS pedidos;
CREATE TABLE `pedidos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `id_dep` int(11) NOT NULL,
  `codigo` int(11) default NULL,
  `cant` float default NULL,
  `peso` float default NULL,
  `tipo` char(1) default NULL,
  `estado` char(1) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pedidos`
--

LOCK TABLES pedidos WRITE;
INSERT INTO pedidos VALUES('1', '<b>Pedido N&ordm; 1827</b>', '0', '1827', '0', '0', 'P', 'F');
INSERT INTO pedidos VALUES('2', 'Vendedor N&ordm; 1', '1', '1', '0', '0', 'V', '-');
INSERT INTO pedidos VALUES('3', 'Ped. 1: Cliente N&ordm; 9018', '2', '9018', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('4', 'Art. 3111 - Cant: 12.00', '3', '3111', '12', '0', 'A', '-');
INSERT INTO pedidos VALUES('5', 'Ped. 2: Cliente N&ordm; 9254', '2', '9254', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('6', 'Art. 1111 - Cant: 20.00', '5', '1111', '20', '3', 'A', '-');
INSERT INTO pedidos VALUES('7', 'Art. 1112 - Cant: 30.00', '5', '1112', '30', '5', 'A', '-');
INSERT INTO pedidos VALUES('8', 'Art. 1113 - Cant: 40.00', '5', '1113', '40', '8', 'A', '-');
INSERT INTO pedidos VALUES('9', 'Art. 1114 - Cant: 50.00', '5', '1114', '50', '0', 'A', '-');
INSERT INTO pedidos VALUES('10', '<b>Pedido N&ordm; 1902</b>', '0', '1902', '0', '0', 'P', 'F');
INSERT INTO pedidos VALUES('11', 'Vendedor N&ordm; 1', '10', '1', '0', '0', 'V', '-');
INSERT INTO pedidos VALUES('12', 'Ped. 1: Cliente N&ordm; 9016', '11', '9016', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('13', 'Art. 13211 - Cant: 1.00', '12', '13211', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('14', '<b>Pedido N&ordm; 1052</b>', '0', '1052', '0', '0', 'P', 'F');
INSERT INTO pedidos VALUES('15', 'Vendedor N&ordm; 1', '14', '1', '0', '0', 'V', '-');
INSERT INTO pedidos VALUES('16', 'Ped. 1: Cliente N&ordm; 9016', '15', '9016', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('17', 'Art. 1111 - Cant: 2.00', '16', '1111', '2', '0', 'A', '-');
INSERT INTO pedidos VALUES('18', 'Art. 1112 - Cant: 5.00', '16', '1112', '5', '25', 'A', '-');
INSERT INTO pedidos VALUES('19', 'Art. 1113 - Cant: 3.00', '16', '1113', '3', '0', 'A', '-');
INSERT INTO pedidos VALUES('20', 'Art. 1113 - Cant: 4.00', '16', '1113', '4', '0', 'A', '-');
INSERT INTO pedidos VALUES('21', 'Art. 12111 - Cant: 1.00', '16', '12111', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('22', 'Ped. 2: Cliente N&ordm; 9119', '15', '9119', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('23', 'Art. 2111 - Cant: 9.00', '22', '2111', '9', '3', 'A', '-');
INSERT INTO pedidos VALUES('24', 'Art. 2113 - Cant: 6.00', '22', '2113', '6', '0', 'A', '-');
INSERT INTO pedidos VALUES('25', 'Art. 2114 - Cant: 10.00', '22', '2114', '10', '6', 'A', '-');
INSERT INTO pedidos VALUES('26', 'Ped. 3: Cliente N&ordm; 9210', '15', '9210', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('27', 'Art. 1111 - Cant: 0.50', '26', '1111', '0.5', '5', 'A', '-');
INSERT INTO pedidos VALUES('28', 'Art. 1112 - Cant: 20.00', '26', '1112', '20', '0', 'A', '-');
INSERT INTO pedidos VALUES('29', 'Art. 1113 - Cant: 3.50', '26', '1113', '3.5', '10', 'A', '-');
INSERT INTO pedidos VALUES('30', 'Ped. 4: Cliente N&ordm; 9737', '15', '9737', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('31', 'Art. 7711 - Cant: 2.00', '30', '7711', '2', '50', 'A', '-');
INSERT INTO pedidos VALUES('32', 'Art. 21011 - Cant: 6.00', '30', '21011', '6', '0', 'A', '-');
INSERT INTO pedidos VALUES('33', 'Art. 21021 - Cant: 2.00', '30', '21021', '2', '0', 'A', '-');
INSERT INTO pedidos VALUES('34', 'Art. 71014 - Cant: 4.00', '30', '71014', '4', '0', 'A', '-');
INSERT INTO pedidos VALUES('35', 'Art. 1111 - Cant: 3.00', '30', '1111', '3', '0', 'A', '-');
INSERT INTO pedidos VALUES('36', 'Ped. 5: Cliente N&ordm; 9739', '15', '9739', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('37', 'Art. 7911 - Cant: 2.00', '36', '7911', '2', '0', 'A', '-');
INSERT INTO pedidos VALUES('38', '<b>Pedido N&ordm; 1117</b>', '0', '1117', '0', '0', 'P', 'F');
INSERT INTO pedidos VALUES('39', 'Vendedor N&ordm; 1', '38', '1', '0', '0', 'V', '-');
INSERT INTO pedidos VALUES('40', 'Ped. 1: Cliente N&ordm; 9259', '39', '9259', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('41', 'Art. 1111 - Cant: 1.00', '40', '1111', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('42', 'Art. 1112 - Cant: 2.00', '40', '1112', '2', '5', 'A', '-');
INSERT INTO pedidos VALUES('43', 'Art. 1113 - Cant: 3.00', '40', '1113', '3', '1', 'A', '-');
INSERT INTO pedidos VALUES('44', '<b>Pedido N&ordm; 1133</b>', '0', '1133', '0', '0', 'P', 'F');
INSERT INTO pedidos VALUES('45', 'Vendedor N&ordm; 1', '44', '1', '0', '0', 'V', '-');
INSERT INTO pedidos VALUES('46', 'Ped. 1: Cliente N&ordm; 9015', '45', '9015', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('47', 'Art. 3111 - Cant: 3.00', '46', '3111', '3', '10', 'A', '-');
INSERT INTO pedidos VALUES('48', 'Ped. 2: Cliente N&ordm; 9018', '45', '9018', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('49', 'Art. 2211 - Cant: 30.00', '48', '2211', '30', '2', 'A', '-');
INSERT INTO pedidos VALUES('50', 'Art. 2112 - Cant: 23.00', '48', '2112', '23', '6', 'A', '-');
INSERT INTO pedidos VALUES('51', 'Ped. 3: Cliente N&ordm; 9254', '45', '9254', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('52', 'Art. 1111 - Cant: 5.00', '51', '1111', '5', '2', 'A', '-');
INSERT INTO pedidos VALUES('53', 'Art. 1112 - Cant: 10.00', '51', '1112', '10', '0', 'A', '-');
INSERT INTO pedidos VALUES('54', '<b>Pedido N&ordm; 1643</b>', '0', '1643', '0', '0', 'P', '-');
INSERT INTO pedidos VALUES('55', 'Vendedor N&ordm; 1', '54', '1', '0', '0', 'V', '-');
INSERT INTO pedidos VALUES('56', 'Ped. 1: Cliente N&ordm; 9119', '55', '9119', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('57', 'Art. 5215 - Cant: 10.00', '56', '5215', '10', '5', 'A', '-');
INSERT INTO pedidos VALUES('58', 'Art. 71632 - Cant: 1.00', '56', '71632', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('59', '<b>Pedido N&ordm; 0823</b>', '0', '823', '0', '0', 'P', 'F');
INSERT INTO pedidos VALUES('60', 'Vendedor N&ordm; 1', '59', '1', '0', '0', 'V', '-');
INSERT INTO pedidos VALUES('61', 'Ped. 1: Cliente N&ordm; 9003', '60', '9003', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('62', 'Art. 1111 - Cant: 5.00', '61', '1111', '5', '0', 'A', '-');
INSERT INTO pedidos VALUES('63', 'Art. 3111 - Cant: 5.00', '61', '3111', '5', '0', 'A', '-');
INSERT INTO pedidos VALUES('64', 'Art. 3112 - Cant: 5.00', '61', '3112', '5', '0', 'A', '-');
INSERT INTO pedidos VALUES('65', 'Art. 3115 - Cant: 3.00', '61', '3115', '3', '0', 'A', '-');
INSERT INTO pedidos VALUES('66', 'Art. 3116 - Cant: 3.00', '61', '3116', '3', '0', 'A', '-');
INSERT INTO pedidos VALUES('67', 'Art. 3117 - Cant: 3.00', '61', '3117', '3', '0', 'A', '-');
INSERT INTO pedidos VALUES('68', 'Art. 3118 - Cant: 5.00', '61', '3118', '5', '0', 'A', '-');
INSERT INTO pedidos VALUES('69', 'Art. 3121 - Cant: 1.00', '61', '3121', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('70', 'Art. 3122 - Cant: 1.00', '61', '3122', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('71', 'Art. 3123 - Cant: 1.00', '61', '3123', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('72', 'Art. 3124 - Cant: 1.00', '61', '3124', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('73', 'Art. 3125 - Cant: 1.00', '61', '3125', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('74', 'Art. 3127 - Cant: 1.00', '61', '3127', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('75', 'Art. 3128 - Cant: 1.00', '61', '3128', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('76', 'Art. 3131 - Cant: 1.00', '61', '3131', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('77', 'Art. 3132 - Cant: 1.00', '61', '3132', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('78', 'Art. 3133 - Cant: 1.00', '61', '3133', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('79', 'Art. 3134 - Cant: 1.00', '61', '3134', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('80', 'Art. 3137 - Cant: 1.00', '61', '3137', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('81', 'Art. 3138 - Cant: 1.00', '61', '3138', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('82', 'Art. 3212 - Cant: 2.00', '61', '3212', '2', '0', 'A', '-');
INSERT INTO pedidos VALUES('83', 'Art. 3215 - Cant: 3.00', '61', '3215', '3', '0', 'A', '-');
INSERT INTO pedidos VALUES('84', 'Art. 3216 - Cant: 3.00', '61', '3216', '3', '0', 'A', '-');
INSERT INTO pedidos VALUES('85', 'Art. 6211 - Cant: 3.00', '61', '6211', '3', '0', 'A', '-');
INSERT INTO pedidos VALUES('86', 'Art. 4211 - Cant: 2.00', '61', '4211', '2', '0', 'A', '-');
INSERT INTO pedidos VALUES('87', 'Art. 6111 - Cant: 4.00', '61', '6111', '4', '0', 'A', '-');
INSERT INTO pedidos VALUES('88', 'Art. 6114 - Cant: 1.00', '61', '6114', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('89', 'Art. 6116 - Cant: 1.00', '61', '6116', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('90', 'Art. 5311 - Cant: 8.00', '61', '5311', '8', '0', 'A', '-');
INSERT INTO pedidos VALUES('91', 'Art. 5312 - Cant: 8.00', '61', '5312', '8', '0', 'A', '-');
INSERT INTO pedidos VALUES('92', 'Art. 5313 - Cant: 8.00', '61', '5313', '8', '0', 'A', '-');
INSERT INTO pedidos VALUES('93', 'Art. 5314 - Cant: 8.00', '61', '5314', '8', '0', 'A', '-');
INSERT INTO pedidos VALUES('94', 'Art. 5315 - Cant: 8.00', '61', '5315', '8', '0', 'A', '-');
INSERT INTO pedidos VALUES('95', 'Art. 5316 - Cant: 8.00', '61', '5316', '8', '0', 'A', '-');
INSERT INTO pedidos VALUES('96', 'Art. 6214 - Cant: 1.00', '61', '6214', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('97', 'Art. 2112 - Cant: 4.00', '61', '2112', '4', '0', 'A', '-');
INSERT INTO pedidos VALUES('98', 'Art. 2132 - Cant: 1.00', '61', '2132', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('99', 'Art. 2122 - Cant: 3.00', '61', '2122', '3', '0', 'A', '-');
INSERT INTO pedidos VALUES('100', 'Art. 2311 - Cant: 2.00', '61', '2311', '2', '0', 'A', '-');
INSERT INTO pedidos VALUES('101', 'Art. 2313 - Cant: 1.00', '61', '2313', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('102', 'Art. 2315 - Cant: 1.00', '61', '2315', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('103', 'Art. 2316 - Cant: 1.00', '61', '2316', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('104', 'Art. 2411 - Cant: 5.00', '61', '2411', '5', '0', 'A', '-');
INSERT INTO pedidos VALUES('105', 'Art. 2611 - Cant: 6.00', '61', '2611', '6', '0', 'A', '-');
INSERT INTO pedidos VALUES('106', 'Art. 2822 - Cant: 6.00', '61', '2822', '6', '0', 'A', '-');
INSERT INTO pedidos VALUES('107', 'Art. 2814 - Cant: 6.00', '61', '2814', '6', '0', 'A', '-');
INSERT INTO pedidos VALUES('108', 'Art. 2813 - Cant: 6.00', '61', '2813', '6', '0', 'A', '-');
INSERT INTO pedidos VALUES('109', 'Art. 2811 - Cant: 6.00', '61', '2811', '6', '0', 'A', '-');
INSERT INTO pedidos VALUES('110', 'Art. 2815 - Cant: 6.00', '61', '2815', '6', '0', 'A', '-');
INSERT INTO pedidos VALUES('111', 'Art. 6313 - Cant: 1.00', '61', '6313', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('112', 'Art. 6312 - Cant: 2.00', '61', '6312', '2', '0', 'A', '-');
INSERT INTO pedidos VALUES('113', 'Art. 6322 - Cant: 2.00', '61', '6322', '2', '0', 'A', '-');
INSERT INTO pedidos VALUES('114', 'Art. 6332 - Cant: 2.00', '61', '6332', '2', '0', 'A', '-');
INSERT INTO pedidos VALUES('115', 'Art. 6361 - Cant: 2.00', '61', '6361', '2', '0', 'A', '-');
INSERT INTO pedidos VALUES('116', 'Ped. 2: Cliente N&ordm; 9040', '60', '9040', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('117', 'Art. 1113 - Cant: 1.00', '116', '1113', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('118', 'Art. 3117 - Cant: 1.00', '116', '3117', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('119', 'Art. 6212 - Cant: 1.00', '116', '6212', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('120', 'Art. 6222 - Cant: 1.00', '116', '6222', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('121', 'Art. 6111 - Cant: 1.00', '116', '6111', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('122', 'Art. 6116 - Cant: 1.00', '116', '6116', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('123', 'Ped. 3: Cliente N&ordm; 9223', '60', '9223', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('124', 'Art. 1111 - Cant: 1.00', '123', '1111', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('125', 'Ped. 4: Cliente N&ordm; 9259', '60', '9259', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('126', 'Art. 1111 - Cant: 5.00', '125', '1111', '5', '0', 'A', '-');
INSERT INTO pedidos VALUES('127', 'Art. 1112 - Cant: 2.00', '125', '1112', '2', '0', 'A', '-');
INSERT INTO pedidos VALUES('128', 'Art. 1114 - Cant: 1.00', '125', '1114', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('129', '<b>Pedido N&ordm; 1445</b>', '0', '1445', '0', '0', 'P', '-');
INSERT INTO pedidos VALUES('130', 'Vendedor N&ordm; 1', '129', '1', '0', '0', 'V', '-');
INSERT INTO pedidos VALUES('131', 'Ped. 1: Cliente N&ordm; 9023', '130', '9023', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('132', 'Art. 1111 - Cant: 1.00', '131', '1111', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('133', 'Art. 2123 - Cant: 1.00', '131', '2123', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('134', 'Ped. 2: Cliente N&ordm; 9041', '130', '9041', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('135', 'Art. 1711 - Cant: 1.00', '134', '1711', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('136', 'Art. 6213 - Cant: 1.00', '134', '6213', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('137', 'Art. 6121 - Cant: 2.00', '134', '6121', '2', '0', 'A', '-');
INSERT INTO pedidos VALUES('138', 'Art. 6313 - Cant: 1.00', '134', '6313', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('139', 'Ped. 3: Cliente N&ordm; 9045', '130', '9045', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('140', 'Art. 1111 - Cant: 15.00', '139', '1111', '15', '0', 'A', '-');
INSERT INTO pedidos VALUES('141', 'Art. 1112 - Cant: 1.00', '139', '1112', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('142', 'Art. 1113 - Cant: 1.00', '139', '1113', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('143', 'Art. 1211 - Cant: 2.00', '139', '1211', '2', '0', 'A', '-');
INSERT INTO pedidos VALUES('144', 'Art. 1213 - Cant: 1.00', '139', '1213', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('145', 'Art. 1711 - Cant: 2.00', '139', '1711', '2', '0', 'A', '-');
INSERT INTO pedidos VALUES('146', 'Art. 1312 - Cant: 1.00', '139', '1312', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('147', 'Art. 6111 - Cant: 1.00', '139', '6111', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('148', 'Art. 6114 - Cant: 1.00', '139', '6114', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('149', 'Art. 6112 - Cant: 1.00', '139', '6112', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('150', 'Art. 6116 - Cant: 1.00', '139', '6116', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('151', 'Art. 6113 - Cant: 1.00', '139', '6113', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('152', 'Ped. 4: Cliente N&ordm; 9062', '130', '9062', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('153', 'Art. 6212 - Cant: 2.00', '152', '6212', '2', '0', 'A', '-');
INSERT INTO pedidos VALUES('154', 'Art. 6213 - Cant: 1.00', '152', '6213', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('155', 'Art. 6116 - Cant: 1.00', '152', '6116', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('156', 'Ped. 5: Cliente N&ordm; 9063', '130', '9063', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('157', 'Art. 1111 - Cant: 1.00', '156', '1111', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('158', 'Art. 2123 - Cant: 1.00', '156', '2123', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('159', 'Ped. 6: Cliente N&ordm; 9067', '130', '9067', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('160', 'Art. 1111 - Cant: 1.00', '159', '1111', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('161', 'Art. 1211 - Cant: 1.00', '159', '1211', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('162', 'Art. 3121 - Cant: 1.00', '159', '3121', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('163', 'Art. 3122 - Cant: 1.00', '159', '3122', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('164', 'Art. 3123 - Cant: 1.00', '159', '3123', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('165', 'Art. 3127 - Cant: 1.00', '159', '3127', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('166', 'Art. 3131 - Cant: 1.00', '159', '3131', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('167', 'Art. 3132 - Cant: 1.00', '159', '3132', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('168', 'Art. 3133 - Cant: 1.00', '159', '3133', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('169', 'Art. 6212 - Cant: 1.00', '159', '6212', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('170', 'Art. 6213 - Cant: 1.00', '159', '6213', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('171', 'Art. 6111 - Cant: 1.00', '159', '6111', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('172', 'Art. 6114 - Cant: 1.00', '159', '6114', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('173', 'Art. 5312 - Cant: 1.00', '159', '5312', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('174', 'Art. 5316 - Cant: 1.00', '159', '5316', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('175', 'Art. 5313 - Cant: 1.00', '159', '5313', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('176', 'Art. 2111 - Cant: 1.00', '159', '2111', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('177', 'Ped. 7: Cliente N&ordm; 9075', '130', '9075', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('178', 'Art. 1111 - Cant: 4.00', '177', '1111', '4', '3', 'A', '-');
INSERT INTO pedidos VALUES('179', 'Art. 1211 - Cant: 1.00', '177', '1211', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('180', 'Art. 1911 - Cant: 3.00', '177', '1911', '3', '0', 'A', '-');
INSERT INTO pedidos VALUES('181', 'Art. 1711 - Cant: 1.00', '177', '1711', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('182', 'Ped. 8: Cliente N&ordm; 9095', '130', '9095', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('183', 'Art. 1111 - Cant: 3.00', '182', '1111', '3', '3', 'A', '-');
INSERT INTO pedidos VALUES('184', 'Art. 3113 - Cant: 1.00', '182', '3113', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('185', 'Art. 3114 - Cant: 1.00', '182', '3114', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('186', 'Art. 3117 - Cant: 1.00', '182', '3117', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('187', 'Art. 3118 - Cant: 1.00', '182', '3118', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('188', 'Art. 3122 - Cant: 1.00', '182', '3122', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('189', 'Art. 3123 - Cant: 1.00', '182', '3123', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('190', 'Art. 3137 - Cant: 1.00', '182', '3137', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('191', 'Art. 3138 - Cant: 1.00', '182', '3138', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('192', 'Art. 3211 - Cant: 1.00', '182', '3211', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('193', 'Art. 3212 - Cant: 1.00', '182', '3212', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('194', 'Art. 3214 - Cant: 1.00', '182', '3214', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('195', 'Art. 3218 - Cant: 1.00', '182', '3218', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('196', 'Art. 4111 - Cant: 1.00', '182', '4111', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('197', 'Art. 4121 - Cant: 1.00', '182', '4121', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('198', 'Art. 6211 - Cant: 1.00', '182', '6211', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('199', 'Art. 6111 - Cant: 1.00', '182', '6111', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('200', 'Art. 5312 - Cant: 1.00', '182', '5312', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('201', 'Art. 5316 - Cant: 1.00', '182', '5316', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('202', 'Art. 5311 - Cant: 1.00', '182', '5311', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('203', 'Art. 5315 - Cant: 1.00', '182', '5315', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('204', 'Art. 5314 - Cant: 1.00', '182', '5314', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('205', 'Art. 5313 - Cant: 1.00', '182', '5313', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('206', 'Art. 2132 - Cant: 1.00', '182', '2132', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('207', 'Art. 2211 - Cant: 1.00', '182', '2211', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('208', 'Art. 6322 - Cant: 1.00', '182', '6322', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('209', 'Ped. 9: Cliente N&ordm; 9096', '130', '9096', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('210', 'Art. 3123 - Cant: 1.00', '209', '3123', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('211', 'Art. 3127 - Cant: 1.00', '209', '3127', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('212', 'Art. 3128 - Cant: 1.00', '209', '3128', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('213', 'Art. 3133 - Cant: 1.00', '209', '3133', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('214', 'Art. 3137 - Cant: 1.00', '209', '3137', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('215', 'Art. 3138 - Cant: 1.00', '209', '3138', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('216', 'Art. 6123 - Cant: 1.00', '209', '6123', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('217', 'Art. 6114 - Cant: 1.00', '209', '6114', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('218', 'Art. 6112 - Cant: 1.00', '209', '6112', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('219', 'Art. 6116 - Cant: 1.00', '209', '6116', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('220', 'Art. 6214 - Cant: 1.00', '209', '6214', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('221', 'Art. 6313 - Cant: 1.00', '209', '6313', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('222', 'Art. 6332 - Cant: 1.00', '209', '6332', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('223', 'Ped. 10: Cliente N&ordm; 9240', '130', '9240', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('224', 'Art. 1111 - Cant: 10.00', '223', '1111', '10', '5', 'A', '-');
INSERT INTO pedidos VALUES('225', 'Art. 1211 - Cant: 2.00', '223', '1211', '2', '0', 'A', '-');
INSERT INTO pedidos VALUES('226', 'Art. 2111 - Cant: 1.00', '223', '2111', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('227', 'Art. 2212 - Cant: 1.00', '223', '2212', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('228', 'Art. 2311 - Cant: 1.00', '223', '2311', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('229', 'Art. 2315 - Cant: 1.00', '223', '2315', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('230', 'Ped. 11: Cliente N&ordm; 9253', '130', '9253', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('231', 'Art. 1111 - Cant: 4.00', '230', '1111', '4', '3', 'A', '-');
INSERT INTO pedidos VALUES('232', 'Art. 1211 - Cant: 1.00', '230', '1211', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('233', 'Art. 6212 - Cant: 1.00', '230', '6212', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('234', 'Art. 6312 - Cant: 1.00', '230', '6312', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('235', 'Ped. 12: Cliente N&ordm; 9267', '130', '9267', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('236', 'Art. 1111 - Cant: 1.00', '235', '1111', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('237', 'Ped. 13: Cliente N&ordm; 9301', '130', '9301', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('238', 'Art. 1213 - Cant: 1.00', '237', '1213', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('239', 'Art. 6212 - Cant: 1.00', '237', '6212', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('240', 'Art. 6213 - Cant: 1.00', '237', '6213', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('241', 'Art. 2111 - Cant: 1.00', '237', '2111', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('242', 'Art. 2112 - Cant: 1.00', '237', '2112', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('243', 'Art. 2316 - Cant: 2.00', '237', '2316', '2', '0', 'A', '-');
INSERT INTO pedidos VALUES('244', 'Ped. 14: Cliente N&ordm; 9510', '130', '9510', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('245', 'Art. 1111 - Cant: 1.00', '244', '1111', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('246', 'Ped. 15: Cliente N&ordm; 9520', '130', '9520', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('247', 'Art. 3131 - Cant: 1.00', '246', '3131', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('248', 'Art. 2311 - Cant: 1.00', '246', '2311', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('249', 'Ped. 16: Cliente N&ordm; 9524', '130', '9524', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('250', 'Art. 1911 - Cant: 1.00', '249', '1911', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('251', 'Ped. 17: Cliente N&ordm; 9527', '130', '9527', '0', '0', 'C', '-');
INSERT INTO pedidos VALUES('252', 'Art. 1111 - Cant: 5.00', '251', '1111', '5', '0', 'A', '-');
INSERT INTO pedidos VALUES('253', 'Art. 2113 - Cant: 1.00', '251', '2113', '1', '0', 'A', '-');
INSERT INTO pedidos VALUES('254', 'Art. 2111 - Cant: 2.00', '251', '2111', '2', '0', 'A', '-');
UNLOCK TABLES;


--
-- Table structure for table `perc_iva`
--

DROP TABLE IF EXISTS perc_iva;
CREATE TABLE `perc_iva` (
  `cod_perc_iva` int(11) NOT NULL auto_increment,
  `nombre` text,
  `tasa` float NOT NULL,
  PRIMARY KEY  (`cod_perc_iva`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `perc_iva`
--

LOCK TABLES perc_iva WRITE;
INSERT INTO perc_iva VALUES('1', 'PERCEP.DE IVA RES. 3337', '0');
UNLOCK TABLES;


--
-- Table structure for table `prod_por_categ`
--

DROP TABLE IF EXISTS prod_por_categ;
CREATE TABLE `prod_por_categ` (
  `cod_categoria` int(11) NOT NULL,
  `cod_prod` int(11) NOT NULL,
  `cod_variedad` int(11) NOT NULL,
  `cod_marca` int(11) NOT NULL,
  `cod_grupo` int(11) NOT NULL,
  `precio_vta` float NOT NULL,
  PRIMARY KEY  (`cod_categoria`,`cod_prod`,`cod_variedad`,`cod_marca`,`cod_grupo`),
  KEY `Ref410` (`cod_categoria`),
  KEY `Ref170` (`cod_variedad`,`cod_prod`,`cod_grupo`,`cod_marca`),
  KEY `Refproducto70` (`cod_prod`,`cod_variedad`,`cod_marca`,`cod_grupo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prod_por_categ`
--

LOCK TABLES prod_por_categ WRITE;
INSERT INTO prod_por_categ VALUES('1', '1', '1', '1', '1', '21.35');
INSERT INTO prod_por_categ VALUES('1', '1', '1', '2', '1', '21.36');
INSERT INTO prod_por_categ VALUES('1', '1', '1', '1', '2', '28.35');
INSERT INTO prod_por_categ VALUES('1', '1', '2', '1', '2', '28.35');
INSERT INTO prod_por_categ VALUES('1', '1', '1', '2', '2', '28.35');
INSERT INTO prod_por_categ VALUES('1', '1', '2', '2', '2', '28.35');
INSERT INTO prod_por_categ VALUES('1', '1', '1', '1', '3', '12');
INSERT INTO prod_por_categ VALUES('1', '1', '2', '1', '3', '8');
INSERT INTO prod_por_categ VALUES('1', '2', '1', '1', '5', '800');
INSERT INTO prod_por_categ VALUES('1', '1', '1', '2', '5', '6');
INSERT INTO prod_por_categ VALUES('1', '1', '1', '2', '3', '10');
INSERT INTO prod_por_categ VALUES('1', '1', '1', '1', '5', '6');
INSERT INTO prod_por_categ VALUES('1', '1', '1', '1', '4', '9');
INSERT INTO prod_por_categ VALUES('1', '1', '2', '1', '4', '8');
INSERT INTO prod_por_categ VALUES('1', '1', '1', '2', '4', '19');
INSERT INTO prod_por_categ VALUES('1', '1', '2', '2', '3', '32');
INSERT INTO prod_por_categ VALUES('2', '1', '2', '2', '3', '25.76');
INSERT INTO prod_por_categ VALUES('1', '1', '2', '2', '1', '61.01');
INSERT INTO prod_por_categ VALUES('2', '1', '2', '2', '1', '70.2');
INSERT INTO prod_por_categ VALUES('2', '2', '1', '1', '5', '725');
INSERT INTO prod_por_categ VALUES('2', '1', '2', '2', '2', '24.57');
INSERT INTO prod_por_categ VALUES('2', '1', '2', '1', '4', '19.84');
INSERT INTO prod_por_categ VALUES('2', '1', '2', '1', '3', '21.17');
INSERT INTO prod_por_categ VALUES('2', '1', '2', '1', '2', '24.57');
INSERT INTO prod_por_categ VALUES('1', '1', '2', '2', '5', '65');
INSERT INTO prod_por_categ VALUES('2', '1', '2', '2', '5', '1.45');
INSERT INTO prod_por_categ VALUES('1', '1', '2', '1', '5', '6');
INSERT INTO prod_por_categ VALUES('2', '1', '2', '1', '5', '72.5');
INSERT INTO prod_por_categ VALUES('1', '1', '2', '2', '4', '23');
INSERT INTO prod_por_categ VALUES('2', '1', '2', '2', '4', '24.15');
INSERT INTO prod_por_categ VALUES('2', '1', '1', '2', '5', '27.4');
INSERT INTO prod_por_categ VALUES('2', '1', '1', '2', '4', '19.84');
INSERT INTO prod_por_categ VALUES('2', '1', '1', '2', '3', '21.17');
INSERT INTO prod_por_categ VALUES('2', '1', '1', '2', '2', '24.57');
INSERT INTO prod_por_categ VALUES('2', '1', '1', '2', '1', '24.57');
INSERT INTO prod_por_categ VALUES('2', '1', '1', '1', '5', '27.4');
INSERT INTO prod_por_categ VALUES('2', '1', '1', '1', '4', '19.84');
INSERT INTO prod_por_categ VALUES('2', '1', '1', '1', '3', '21.17');
INSERT INTO prod_por_categ VALUES('2', '1', '1', '1', '2', '24.57');
INSERT INTO prod_por_categ VALUES('2', '1', '1', '1', '1', '24.57');
INSERT INTO prod_por_categ VALUES('1', '1', '2', '1', '1', '20.22');
INSERT INTO prod_por_categ VALUES('2', '1', '2', '1', '1', '23.27');
UNLOCK TABLES;


--
-- Table structure for table `producto`
--

DROP TABLE IF EXISTS producto;
CREATE TABLE `producto` (
  `cod_prod` int(11) NOT NULL,
  `cod_variedad` int(11) NOT NULL,
  `cod_marca` int(11) NOT NULL,
  `cod_grupo` int(11) NOT NULL,
  `descripcion` text NOT NULL,
  `precio_costo` float NOT NULL,
  `envase` char(2) NOT NULL,
  `stock_actual` float NOT NULL,
  `stock_min` float NOT NULL,
  `stock_max` float default NULL,
  `foto` text NOT NULL,
  `cod_proveedor` int(11) NOT NULL,
  `medida` float NOT NULL,
  `cod_medida` int(11) NOT NULL,
  `porc_vta` float NOT NULL,
  `porc_transporte` float NOT NULL,
  `unidad_bulto` int(11) NOT NULL,
  `peso` float NOT NULL,
  `activo` varchar(1) NOT NULL,
  `cod_iva` int(11) NOT NULL,
  PRIMARY KEY  (`cod_prod`,`cod_variedad`,`cod_marca`,`cod_grupo`),
  KEY `Ref23` (`cod_marca`,`cod_variedad`,`cod_grupo`),
  KEY `Ref3350` (`cod_proveedor`),
  KEY `Ref1077` (`cod_medida`),
  KEY `Refvariedad3` (`cod_variedad`,`cod_marca`,`cod_grupo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `producto`
--

LOCK TABLES producto WRITE;
INSERT INTO producto VALUES('1', '1', '1', '1', 'SAMSUNG-SATA', '18.91', 'SI', '3964.75', '1', '1', 'N', '1', '970', '1', '1.25', '3', '12', '25', 'S', '1');
INSERT INTO producto VALUES('1', '1', '2', '1', 'SEAGATE-SATA', '18.91', 'SI', '117.25', '1', '1', 'N', '4', '970', '1', '1.25', '3', '12', '25', 'S', '2');
INSERT INTO producto VALUES('1', '1', '1', '2', 'ASUS-FSB 800', '18.91', 'NO', '587.5', '1', '1', 'N', '7', '930', '1', '1.25', '3', '8', '11.29', 'S', '2');
INSERT INTO producto VALUES('1', '2', '1', '2', 'ASUS-FSB 1600', '18.91', 'NO', '281.5', '1', '1', 'N', '6', '930', '1', '1.25', '3', '8', '15', 'S', '2');
INSERT INTO producto VALUES('1', '3', '1', '2', 'NATIVO 8 X 1 BLANCO', '18.91', 'NO', '63', '1', '1', 'N', '2', '930', '1', '1.25', '3', '8', '15', 'S', '2');
INSERT INTO producto VALUES('1', '1', '2', '2', 'GIGABYTE-FSB 800', '18.91', 'NO', '412', '1', '1', 'N', '6', '1000', '1', '1.25', '3', '12', '20', 'S', '2');
INSERT INTO producto VALUES('1', '2', '2', '2', 'GIGABYTE-FSB 1600', '18.91', 'NO', '31.5', '1', '1', 'N', '4', '1000', '1', '1.25', '3', '12', '20', 'S', '2');
INSERT INTO producto VALUES('1', '3', '2', '2', 'TORO 12 X 1 BLANCO', '18.91', 'NO', '79', '1', '1', 'N', '2', '1000', '1', '1.25', '3', '12', '20', 'S', '2');
INSERT INTO producto VALUES('1', '1', '1', '3', 'SAMSUNG-LCD', '18.91', 'NO', '-152', '1', '1', 'N', '1', '2125', '1', '1.25', '3', '6', '21', 'S', '2');
INSERT INTO producto VALUES('1', '2', '1', '3', 'SAMSUNG-CRT', '18.91', 'NO', '269.25', '1', '1', 'N', '5', '1000', '1', '1.25', '3', '6', '10', 'S', '2');
INSERT INTO producto VALUES('1', '3', '1', '3', 'TUBITO 6 X 350 COLA', '18.91', 'NO', '433', '1', '1', 'N', '4', '350', '1', '1.25', '3', '6', '6', 'S', '2');
INSERT INTO producto VALUES('1', '1', '2', '5', 'EPSON-LASER', '18.91', 'NO', '480.5', '1', '1', 'N', '1', '500', '1', '1.25', '3', '1', '10', 'S', '2');
INSERT INTO producto VALUES('1', '1', '2', '3', 'WIESONIC-LCD', '18.91', 'NO', '209.5', '1', '1', 'N', '8', '2125', '1', '1.25', '3', '6', '10', 'S', '2');
INSERT INTO producto VALUES('1', '1', '1', '5', 'HP-LASER', '18.91', 'NO', '352', '1', '1', 'N', '6', '1', '1', '1.25', '3', '1', '1', 'S', '2');
INSERT INTO producto VALUES('1', '1', '1', '4', 'AMD-CORE DUO', '18.91', 'NO', '147.5', '1', '1', 'N', '7', '2125', '1', '1.25', '3', '6', '6', 'S', '2');
INSERT INTO producto VALUES('1', '2', '1', '4', 'AMD-CORE 2 DUO', '18.91', 'NO', '107.5', '1', '1', 'N', '2', '1500', '1', '1.25', '3', '6', '5', 'S', '2');
INSERT INTO producto VALUES('1', '1', '2', '4', 'INTEL-CORE DUO', '18.91', 'NO', '2', '1', '1', 'N', '6', '1750', '1', '1.25', '3', '6', '15', 'S', '2');
INSERT INTO producto VALUES('1', '2', '2', '5', 'EPSON-CHORRO A TINTA', '18.91', 'NO', '32', '2', '63', 'N', '5', '32', '1', '2', '1', '32', '65', 'S', '2');
INSERT INTO producto VALUES('1', '2', '1', '1', 'SAMSUNG-IDE', '18.91', 'NO', '-30', '12', '80', 'N', '2', '3', '1', '2', '1.5', '23', '1', 'S', '2');
INSERT INTO producto VALUES('1', '2', '2', '1', 'SEAGATE-IDE', '18.91', 'NO', '26', '12', '63', 'N', '5', '3', '1', '1', '2', '54', '1.5', 'S', '2');
INSERT INTO producto VALUES('1', '2', '1', '5', 'HP-CHORRO A TINTA', '18.91', 'NO', '6', '1', '23', 'N', '3', '3', '1', '3', '2.5', '65', '23', 'S', '2');
INSERT INTO producto VALUES('1', '2', '2', '3', 'WIESONIC-CRT', '18.91', 'NO', '32', '2', '63', 'N', '3', '2', '1', '3', '2', '9', '3', 'S', '2');
INSERT INTO producto VALUES('1', '2', '2', '4', 'INTEL-CORE 2 DUO', '18.91', 'NO', '23', '15', '90', 'N', '10', '3', '1', '2', '1', '65', '1', 'S', '2');
INSERT INTO producto VALUES('2', '1', '1', '5', 'EPSON-LASER-MULTIFUNCION', '500', 'NO', '38', '10', '1000', 'N', '4', '1', '1', '1', '1', '1', '10', 'S', '1');
UNLOCK TABLES;


--
-- Table structure for table `proveedor`
--

DROP TABLE IF EXISTS proveedor;
CREATE TABLE `proveedor` (
  `cod_proveedor` int(11) NOT NULL,
  `razon_social` text NOT NULL,
  `cuit` text NOT NULL,
  `ingreso_bruto` text,
  `direccion` text NOT NULL,
  `tel` text,
  `fax` text,
  `movil` text,
  `contacto` text,
  `web` text,
  `email` text,
  `limite_cred` text,
  `agente_retencion` char(1) NOT NULL,
  `cond_iva` text NOT NULL,
  `cod_localidad` int(11) NOT NULL,
  `cod_prov` int(11) NOT NULL,
  `cod_pais` int(11) NOT NULL,
  PRIMARY KEY  (`cod_proveedor`),
  KEY `Ref1742` (`cod_pais`,`cod_prov`,`cod_localidad`),
  KEY `Reflocalidad42` (`cod_localidad`,`cod_prov`,`cod_pais`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `proveedor`
--

LOCK TABLES proveedor WRITE;
INSERT INTO proveedor VALUES('1', 'AIR COMPUTERS', '30505779858', '9216200187', 'CALCHINES 1401', '03783-425660', '0342-4502200', '', '', '', '', '', 'S', '1', '38', '1', '1');
INSERT INTO proveedor VALUES('2', 'CHIPORITO S.R.L', '30634595623', '9135009681', 'CTE. ESPORA Y HERRERA ', '03752-152443', '', '', 'MUJICA', '', '', '', 'S', '1', '39', '1', '1');
INSERT INTO proveedor VALUES('3', 'COMPUNET S.A', '30602276097', '9083521804', 'VIRGEN DE LUJAN Y ALBERDI', '03456-421632', '', '', '', '', '', '', 'S', '1', '42', '3', '1');
INSERT INTO proveedor VALUES('4', 'NOGANET', '33586981949', '9062912937', 'CALLE 321 NRO. 78', '03732-421800', '', '', '', '', '', '', 'S', '1', '40', '3', '1');
INSERT INTO proveedor VALUES('5', 'INFORMATICA S.A', '30517050225', '9019127179', 'RTA. NACIONAL N° 2 KM 102', '011-49594388', '', ' 03752-15540781', 'MINUTILLO', '', '', '', 'S', '1', '43', '4', '1');
INSERT INTO proveedor VALUES('6', 'REDITEL S.A', '30500710507', '9029139252', 'JUJUY 1197', '011-44698000', '', '', '', '', '', '', 'N', '1', '44', '4', '1');
INSERT INTO proveedor VALUES('7', 'ZONACERONET', '23298402149', '156', 'GRAL PAZ 635', '1596325', '', '', '', '', '', '', 'N', '3', '33', '1', '1');
INSERT INTO proveedor VALUES('8', 'TECOM', '33709776989', '9012230070', 'BOGOTA 311 P. 5 DTO. 20', '011-47552916', '011-47542888', '', '', 'WWW.SIVIAR.COM.AR', 'VENTAS@SIVIAR.COM.AR', '', 'N', '1', '55', '4', '1');
INSERT INTO proveedor VALUES('9', 'NETCOM', '30500548041', '9029127147', 'ARENALES 460 - VICENTE LOPEZ', '011- 51988000', '', '', '', '', '', '', 'S', '1', '55', '4', '1');
INSERT INTO proveedor VALUES('10', 'COMPUCOM', '30708222190', '30708222190', 'RUTA 4,KM.10', '03752430878', '', '0375215561749', '', '', '', '', 'S', '1', '39', '1', '1');
UNLOCK TABLES;


--
-- Table structure for table `provincia`
--

DROP TABLE IF EXISTS provincia;
CREATE TABLE `provincia` (
  `cod_prov` int(11) NOT NULL auto_increment,
  `cod_pais` int(11) NOT NULL,
  `nombre` text NOT NULL,
  PRIMARY KEY  (`cod_prov`,`cod_pais`),
  KEY `Ref811` (`cod_pais`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `provincia`
--

LOCK TABLES provincia WRITE;
INSERT INTO provincia VALUES('1', '1', 'MISIONES');
INSERT INTO provincia VALUES('2', '1', 'CORRIENTES');
INSERT INTO provincia VALUES('3', '1', 'ENTRE RIOS');
INSERT INTO provincia VALUES('4', '1', 'BUENOS AIRES');
INSERT INTO provincia VALUES('5', '1', 'SANTA FE');
INSERT INTO provincia VALUES('6', '1', 'POSADAS');
UNLOCK TABLES;


--
-- Table structure for table `recibos_por_cliente`
--

DROP TABLE IF EXISTS recibos_por_cliente;
CREATE TABLE `recibos_por_cliente` (
  `cod_cliente` int(11) NOT NULL,
  `cod_zona` int(11) NOT NULL,
  `cod_localidad` int(11) NOT NULL,
  `cod_prov` int(11) NOT NULL,
  `cod_pais` int(11) NOT NULL,
  `cod_talonario` char(1) NOT NULL,
  `num_talonario` int(4) unsigned zerofill NOT NULL,
  PRIMARY KEY  (`cod_cliente`,`cod_zona`,`cod_localidad`,`cod_prov`,`cod_pais`,`cod_talonario`,`num_talonario`),
  KEY `Reftalonario130` (`cod_talonario`,`num_talonario`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recibos_por_cliente`
--

LOCK TABLES recibos_por_cliente WRITE;
INSERT INTO recibos_por_cliente VALUES('1', '5', '33', '1', '1', 'C', '0001');
UNLOCK TABLES;


--
-- Table structure for table `regular_comision`
--

DROP TABLE IF EXISTS regular_comision;
CREATE TABLE `regular_comision` (
  `descuento` float NOT NULL,
  `minimo` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `regular_comision`
--

LOCK TABLES regular_comision WRITE;
INSERT INTO regular_comision VALUES('5', '1');
UNLOCK TABLES;


--
-- Table structure for table `remito_compra`
--

DROP TABLE IF EXISTS remito_compra;
CREATE TABLE `remito_compra` (
  `num_remito` int(8) unsigned zerofill NOT NULL,
  `fecha` int(11) NOT NULL,
  `cod_proveedor` int(11) NOT NULL,
  `cod_talonario` char(1) NOT NULL,
  `num_talonario` int(4) unsigned zerofill NOT NULL,
  PRIMARY KEY  (`num_remito`),
  KEY `Ref3348` (`cod_proveedor`),
  KEY `Ref2261` (`num_talonario`,`cod_talonario`),
  KEY `Reftalonario61` (`cod_talonario`,`num_talonario`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `remito_compra`
--

LOCK TABLES remito_compra WRITE;
UNLOCK TABLES;


--
-- Table structure for table `remito_compra_detalle`
--

DROP TABLE IF EXISTS remito_compra_detalle;
CREATE TABLE `remito_compra_detalle` (
  `num_remito` int(8) unsigned zerofill NOT NULL,
  `cod_prod` int(11) NOT NULL,
  `cod_variedad` int(11) NOT NULL,
  `cod_marca` int(11) NOT NULL,
  `cod_grupo` int(11) NOT NULL,
  `cantidad` float NOT NULL,
  `precio` float NOT NULL,
  `bonificacion` float default NULL,
  PRIMARY KEY  (`num_remito`,`cod_prod`,`cod_variedad`,`cod_marca`,`cod_grupo`),
  KEY `Ref3643` (`num_remito`),
  KEY `Ref152` (`cod_variedad`,`cod_prod`,`cod_grupo`,`cod_marca`),
  KEY `Refproducto52` (`cod_prod`,`cod_variedad`,`cod_marca`,`cod_grupo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `remito_compra_detalle`
--

LOCK TABLES remito_compra_detalle WRITE;
UNLOCK TABLES;


--
-- Table structure for table `remito_vta`
--

DROP TABLE IF EXISTS remito_vta;
CREATE TABLE `remito_vta` (
  `num_remito` int(8) unsigned zerofill NOT NULL,
  `fecha` int(11) NOT NULL,
  `lugar_entrega` text,
  `hora_entrega` text,
  `cod_cliente` int(11) NOT NULL,
  `cod_zona` int(11) NOT NULL,
  `cod_localidad` int(11) NOT NULL,
  `cod_prov` int(11) NOT NULL,
  `cod_pais` int(11) NOT NULL,
  `cod_talonario` char(1) NOT NULL,
  `num_talonario` int(4) unsigned zerofill NOT NULL,
  `cod_categoria` int(11) default NULL,
  `cod_vendedor` int(11) default NULL,
  `cod_repartidor` int(11) default NULL,
  `observacion` text,
  `pendiente` varchar(1) default NULL,
  PRIMARY KEY  (`num_remito`),
  KEY `Ref522` (`cod_localidad`,`cod_zona`,`cod_cliente`,`cod_pais`,`cod_prov`),
  KEY `Ref2249` (`cod_talonario`,`num_talonario`),
  KEY `Refcliente22` (`cod_cliente`,`cod_zona`,`cod_localidad`,`cod_prov`,`cod_pais`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `remito_vta`
--

LOCK TABLES remito_vta WRITE;
INSERT INTO remito_vta VALUES('00000001', '20090305', '', '', '1', '5', '33', '1', '1', 'R', '0001', '1', '1', '1', '', 'N');
UNLOCK TABLES;


--
-- Table structure for table `remito_vta_detalle`
--

DROP TABLE IF EXISTS remito_vta_detalle;
CREATE TABLE `remito_vta_detalle` (
  `num_remito` int(8) unsigned zerofill NOT NULL,
  `cod_prod` int(11) NOT NULL,
  `cod_variedad` int(11) NOT NULL,
  `cod_marca` int(11) NOT NULL,
  `cod_grupo` int(11) NOT NULL,
  `cantidad` float NOT NULL,
  `precio` float NOT NULL,
  `bonificacion` float default NULL,
  PRIMARY KEY  (`num_remito`,`cod_prod`,`cod_variedad`,`cod_marca`,`cod_grupo`),
  KEY `Ref125` (`cod_prod`,`cod_grupo`,`cod_marca`,`cod_variedad`),
  KEY `Ref2486` (`num_remito`),
  KEY `Refproducto25` (`cod_prod`,`cod_variedad`,`cod_marca`,`cod_grupo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `remito_vta_detalle`
--

LOCK TABLES remito_vta_detalle WRITE;
INSERT INTO remito_vta_detalle VALUES('00000001', '1', '1', '1', '1', '1', '21.35', '0');
INSERT INTO remito_vta_detalle VALUES('00000001', '2', '1', '1', '5', '1', '800', '0');
UNLOCK TABLES;


--
-- Table structure for table `remito_vta_detalle_no_cliente`
--

DROP TABLE IF EXISTS remito_vta_detalle_no_cliente;
CREATE TABLE `remito_vta_detalle_no_cliente` (
  `num_remito` int(8) unsigned zerofill NOT NULL,
  `cod_prod` int(11) NOT NULL,
  `cod_variedad` int(11) NOT NULL,
  `cod_marca` int(11) NOT NULL,
  `cod_grupo` int(11) NOT NULL,
  `cantidad` float NOT NULL,
  `precio` float NOT NULL,
  `bonificacion` float default NULL,
  PRIMARY KEY  (`num_remito`,`cod_prod`,`cod_variedad`,`cod_marca`,`cod_grupo`),
  KEY `Ref4995` (`num_remito`),
  KEY `Ref1110` (`cod_marca`,`cod_variedad`,`cod_prod`,`cod_grupo`),
  KEY `Refproducto110` (`cod_prod`,`cod_variedad`,`cod_marca`,`cod_grupo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `remito_vta_detalle_no_cliente`
--

LOCK TABLES remito_vta_detalle_no_cliente WRITE;
UNLOCK TABLES;


--
-- Table structure for table `remito_vta_no_cliente`
--

DROP TABLE IF EXISTS remito_vta_no_cliente;
CREATE TABLE `remito_vta_no_cliente` (
  `num_remito` int(8) unsigned zerofill NOT NULL,
  `fecha` int(11) NOT NULL,
  `lugar_entrega` text,
  `hora_entrega` text,
  `cod_talonario` char(1) NOT NULL,
  `num_talonario` int(4) unsigned zerofill NOT NULL,
  `razon_social` text NOT NULL,
  `direccion` text NOT NULL,
  `localidad` text NOT NULL,
  `provincia` text,
  `iva` text,
  `cuit` varchar(11) default NULL,
  `cod_categoria` int(11) default NULL,
  `cod_vendedor` int(11) default NULL,
  `cod_repartidor` int(11) default NULL,
  `observacion` text,
  `zona` int(11) NOT NULL,
  `pendiente` varchar(1) default NULL,
  PRIMARY KEY  (`num_remito`),
  KEY `Ref2290` (`num_talonario`,`cod_talonario`),
  KEY `Reftalonario90` (`cod_talonario`,`num_talonario`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `remito_vta_no_cliente`
--

LOCK TABLES remito_vta_no_cliente WRITE;
UNLOCK TABLES;


--
-- Table structure for table `remito_vta_tmp`
--

DROP TABLE IF EXISTS remito_vta_tmp;
CREATE TABLE `remito_vta_tmp` (
  `usuario` text,
  `cod_prod` int(11) default NULL,
  `descripcion` text,
  `cantidad` float NOT NULL,
  `precio` float NOT NULL,
  `bonificacion` float default NULL,
  `importe` float default NULL,
  `linea` int(11) default NULL,
  `iva` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `remito_vta_tmp`
--

LOCK TABLES remito_vta_tmp WRITE;
INSERT INTO remito_vta_tmp VALUES('admin', '1111', 'SAMSUNG-SATA', '2', '21.35', '4', '40.99', '1', '21');
UNLOCK TABLES;


--
-- Table structure for table `sis_preventa`
--

DROP TABLE IF EXISTS sis_preventa;
CREATE TABLE `sis_preventa` (
  `url` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sis_preventa`
--

LOCK TABLES sis_preventa WRITE;
UNLOCK TABLES;


--
-- Table structure for table `stock_inicial`
--

DROP TABLE IF EXISTS stock_inicial;
CREATE TABLE `stock_inicial` (
  `fecha` int(11) default NULL,
  `ususario` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock_inicial`
--

LOCK TABLES stock_inicial WRITE;
INSERT INTO stock_inicial VALUES('20080830', 'alonso');
UNLOCK TABLES;


--
-- Table structure for table `talonario`
--

DROP TABLE IF EXISTS talonario;
CREATE TABLE `talonario` (
  `cod_talonario` char(1) NOT NULL,
  `num_talonario` int(4) unsigned zerofill NOT NULL,
  `n_sucursal` int(4) unsigned zerofill NOT NULL,
  `destino_impr` text,
  `max_iter` int(11) NOT NULL,
  `primer_num` int(8) unsigned zerofill NOT NULL,
  `ultimo_num` int(8) unsigned zerofill NOT NULL,
  `sig_num` int(8) unsigned zerofill NOT NULL,
  `fecha_venc` int(11) NOT NULL,
  `num_cai` text NOT NULL,
  PRIMARY KEY  (`cod_talonario`,`num_talonario`),
  KEY `Ref2529` (`cod_talonario`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `talonario`
--

LOCK TABLES talonario WRITE;
INSERT INTO talonario VALUES('A', '0001', '0001', 'epsonlx300#EPSON LX-300', '35', '00000001', '00001000', '00000001', '20102009', '27681113320534');
INSERT INTO talonario VALUES('B', '0001', '0001', 'epsonlx300#EPSON LX-300', '35', '00000001', '00001000', '00000001', '10102009', '276811133205');
INSERT INTO talonario VALUES('R', '0001', '0001', 'HP-LaserJet-M1319f-MFP#HP LaserJet M1319f', '20', '00000001', '00001000', '00000001', '10102009', '28681107914228');
INSERT INTO talonario VALUES('C', '0001', '0001', 'HP-LaserJet-M1319f-MFP#HP LaserJet M1319f', '25', '00000001', '00001000', '00000001', '10102009', '56702312984563');
INSERT INTO talonario VALUES('D', '0001', '0001', 'HP-LaserJet-M1319f-MFP#HP LaserJet M1319f', '12', '00000001', '00001000', '00000001', '10102009', '38740123886403');
UNLOCK TABLES;


--
-- Table structure for table `tipo_talonario`
--

DROP TABLE IF EXISTS tipo_talonario;
CREATE TABLE `tipo_talonario` (
  `cod_talonario` char(1) NOT NULL,
  `descripcion` text NOT NULL,
  `cant_copias` int(11) NOT NULL,
  PRIMARY KEY  (`cod_talonario`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tipo_talonario`
--

LOCK TABLES tipo_talonario WRITE;
INSERT INTO tipo_talonario VALUES('A', 'FAC A', '1');
INSERT INTO tipo_talonario VALUES('B', 'FAC B', '1');
INSERT INTO tipo_talonario VALUES('R', 'REMITO', '1');
INSERT INTO tipo_talonario VALUES('C', 'RECIBO DE COBRANZAS', '1');
INSERT INTO tipo_talonario VALUES('X', 'PRESUPUESTOS', '1');
INSERT INTO tipo_talonario VALUES('D', 'DEVOLUCIONES (REBOTE)', '1');
UNLOCK TABLES;


--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS usuario;
CREATE TABLE `usuario` (
  `cod_usuario` int(11) NOT NULL auto_increment,
  `usuario` char(20) NOT NULL,
  `clave` text NOT NULL,
  `nombre` text NOT NULL,
  `abm_zonas_geo` char(1) NOT NULL,
  `abm_alicuotas` varchar(1) NOT NULL,
  `abm_comprobante` varchar(1) NOT NULL,
  `abm_cond_iva` varchar(1) NOT NULL,
  `abm_talonario` varchar(1) NOT NULL,
  `abm_proveedor` varchar(1) NOT NULL,
  `abm_vehiculo` varchar(1) NOT NULL,
  `abm_repartidor` varchar(1) NOT NULL,
  `abm_vendedor` varchar(1) NOT NULL,
  `abm_categoria` varchar(1) NOT NULL,
  `abm_forma_pago` varchar(1) NOT NULL,
  `abm_cliente` varchar(1) NOT NULL,
  `abm_articulo` varchar(1) NOT NULL,
  `datos_empresa` varchar(1) NOT NULL,
  `conf_listados` varchar(1) NOT NULL,
  `abm_usuarios` varchar(1) NOT NULL,
  `stock` varchar(1) NOT NULL,
  `factura_compra` varchar(1) NOT NULL,
  `remito_vta` varchar(1) NOT NULL,
  `factura_vta` varchar(1) NOT NULL,
  `nota_credito` varchar(1) NOT NULL,
  `cta_cte` varchar(1) NOT NULL,
  `comisiones` varchar(1) NOT NULL,
  `devoluciones` varchar(1) NOT NULL,
  `finalizar_carga` varchar(1) NOT NULL,
  `informes` varchar(1) NOT NULL,
  `estadisticas` varchar(1) NOT NULL,
  `utilidades` varchar(1) NOT NULL,
  `activo` varchar(1) NOT NULL,
  PRIMARY KEY  (`cod_usuario`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuario`
--

LOCK TABLES usuario WRITE;
INSERT INTO usuario VALUES('17', 'admin', '2a52adc7b1da6a4e0a7a14e4c8db1b11', 'BETO', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S');
INSERT INTO usuario VALUES('18', 'mariana', '0196f6c4f97df3f48d570c23e46501ae', 'MARIANA', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S');
INSERT INTO usuario VALUES('19', 'fabian', 'e982a1d9df63a418d43776debb08b542', 'FABIAN', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S');
INSERT INTO usuario VALUES('21', 'lucas', '85b5881c679542738ed5c75b4e38b724', 'LUCAS', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S', 'S');
UNLOCK TABLES;


--
-- Table structure for table `variedad`
--

DROP TABLE IF EXISTS variedad;
CREATE TABLE `variedad` (
  `cod_variedad` int(11) NOT NULL,
  `cod_marca` int(11) NOT NULL,
  `cod_grupo` int(11) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY  (`cod_variedad`,`cod_marca`,`cod_grupo`),
  KEY `Ref122` (`cod_grupo`,`cod_marca`),
  KEY `Refmarca2` (`cod_marca`,`cod_grupo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `variedad`
--

LOCK TABLES variedad WRITE;
INSERT INTO variedad VALUES('1', '1', '2', 'FSB 800');
INSERT INTO variedad VALUES('2', '1', '2', 'FSB 1600');
INSERT INTO variedad VALUES('1', '2', '2', 'FSB 800');
INSERT INTO variedad VALUES('2', '2', '2', 'FSB 1600');
INSERT INTO variedad VALUES('1', '3', '2', 'TINTO');
INSERT INTO variedad VALUES('2', '3', '2', 'ROSADO');
INSERT INTO variedad VALUES('2', '2', '1', 'IDE');
INSERT INTO variedad VALUES('1', '4', '2', 'TINTO');
INSERT INTO variedad VALUES('2', '4', '2', 'ROSADO');
INSERT INTO variedad VALUES('2', '1', '1', 'IDE');
INSERT INTO variedad VALUES('1', '5', '2', 'UNICA');
INSERT INTO variedad VALUES('1', '6', '2', 'TINTO');
INSERT INTO variedad VALUES('2', '6', '2', 'BLANCO');
INSERT INTO variedad VALUES('1', '7', '2', 'UNICA');
INSERT INTO variedad VALUES('1', '8', '2', 'TINTO');
INSERT INTO variedad VALUES('2', '8', '2', 'BLANCO');
INSERT INTO variedad VALUES('1', '9', '2', 'TINTO');
INSERT INTO variedad VALUES('2', '9', '2', 'TORRONTES');
INSERT INTO variedad VALUES('1', '10', '2', 'UNICA');
INSERT INTO variedad VALUES('1', '1', '3', 'LCD');
INSERT INTO variedad VALUES('2', '1', '3', 'CRT');
INSERT INTO variedad VALUES('1', '2', '3', 'LCD');
INSERT INTO variedad VALUES('1', '1', '4', 'CORE DUO');
INSERT INTO variedad VALUES('2', '1', '4', 'CORE 2 DUO');
INSERT INTO variedad VALUES('1', '2', '4', 'CORE DUO');
INSERT INTO variedad VALUES('1', '1', '5', 'LASER');
INSERT INTO variedad VALUES('1', '2', '5', 'LASER');
INSERT INTO variedad VALUES('1', '3', '5', 'POLVO');
INSERT INTO variedad VALUES('1', '11', '2', 'UNICA');
INSERT INTO variedad VALUES('2', '5', '5', 'LIQUIDO');
INSERT INTO variedad VALUES('1', '1', '1', 'SATA');
INSERT INTO variedad VALUES('1', '2', '1', 'SATA');
INSERT INTO variedad VALUES('1', '3', '1', 'UNICA');
INSERT INTO variedad VALUES('1', '4', '1', 'UNICA');
INSERT INTO variedad VALUES('1', '5', '1', 'UNICA');
INSERT INTO variedad VALUES('1', '6', '1', 'UNICA');
INSERT INTO variedad VALUES('1', '12', '2', 'TINTO');
INSERT INTO variedad VALUES('1', '13', '2', 'UNICO');
INSERT INTO variedad VALUES('2', '12', '2', 'BLANCO');
INSERT INTO variedad VALUES('2', '2', '5', 'CHORRO A TINTA');
INSERT INTO variedad VALUES('2', '1', '5', 'CHORRO A TINTA');
INSERT INTO variedad VALUES('2', '2', '4', 'CORE 2 DUO');
INSERT INTO variedad VALUES('2', '10', '2', 'BLANCO');
INSERT INTO variedad VALUES('2', '2', '3', 'CRT');
INSERT INTO variedad VALUES('1', '7', '1', 'UNICA');
INSERT INTO variedad VALUES('1', '8', '1', 'UNICA');
INSERT INTO variedad VALUES('1', '9', '1', 'UNICA');
INSERT INTO variedad VALUES('1', '3', '4', 'UNICA');
INSERT INTO variedad VALUES('2', '7', '2', 'BLANCO');
INSERT INTO variedad VALUES('2', '6', '5', 'LIQUIDO');
INSERT INTO variedad VALUES('1', '4', '5', 'UNICA');
UNLOCK TABLES;


--
-- Table structure for table `vehiculo`
--

DROP TABLE IF EXISTS vehiculo;
CREATE TABLE `vehiculo` (
  `cod_vehiculo` int(11) NOT NULL,
  `patente` text NOT NULL,
  `patente_acop` text NOT NULL,
  `marca` text NOT NULL,
  `modelo` text NOT NULL,
  `propiedad` char(1) default NULL,
  PRIMARY KEY  (`cod_vehiculo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehiculo`
--

LOCK TABLES vehiculo WRITE;
INSERT INTO vehiculo VALUES('1', 'URF 569', '', 'FORD -350', '1985', 'N');
INSERT INTO vehiculo VALUES('2', 'ASDDF', '', 'FORD-250', '1970', 'N');
INSERT INTO vehiculo VALUES('3', 'UHF211', '', 'FORD-350', '1985', 'N');
INSERT INTO vehiculo VALUES('4', 'TSK282', '', 'FORD 14000', '1982', 'N');
INSERT INTO vehiculo VALUES('5', 'UOK361', '', 'MERCEDEZ BENZ 1114', '1979', 'N');
INSERT INTO vehiculo VALUES('6', 'RBY 439', '', 'MERCEDES BENZ 1114', '1967', 'N');
INSERT INTO vehiculo VALUES('7', 'RTY 429', '', 'FORD 350', '1973', 'N');
INSERT INTO vehiculo VALUES('8', 'GMO285', 'GMO291', 'RENAULT', '2007', 'S');
INSERT INTO vehiculo VALUES('20', 'FMF534', '', 'SAVEIRO', '2006', 'N');
INSERT INTO vehiculo VALUES('9', 'NNNNN', '', 'MERCEDES', '1111', 'N');
INSERT INTO vehiculo VALUES('21', 'DEPOSIT', 'XXX', 'XXX', 'XXX', 'N');
UNLOCK TABLES;


--
-- Table structure for table `vendedor`
--

DROP TABLE IF EXISTS vendedor;
CREATE TABLE `vendedor` (
  `cod_vendedor` int(11) NOT NULL,
  `dni` int(11) NOT NULL,
  `nombre` text NOT NULL,
  `direccion` text NOT NULL,
  `tel` text NOT NULL,
  `cod_localidad` int(11) NOT NULL,
  `cod_prov` int(11) NOT NULL,
  `cod_pais` int(11) NOT NULL,
  PRIMARY KEY  (`cod_vendedor`),
  KEY `Ref1780` (`cod_pais`,`cod_prov`,`cod_localidad`),
  KEY `Reflocalidad80` (`cod_localidad`,`cod_prov`,`cod_pais`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendedor`
--

LOCK TABLES vendedor WRITE;
INSERT INTO vendedor VALUES('1', '21300727', 'BARCHUK JUAN CARLOS', 'APOSTOLES', '3758-408161', '33', '1', '1');
INSERT INTO vendedor VALUES('2', '23256842', 'RECALDE LUIS', 'B. ILLIA', '3758-418500', '33', '1', '1');
INSERT INTO vendedor VALUES('3', '1', 'MIGUEL CARPES', 'VIRASORO', '11', '26', '2', '1');
INSERT INTO vendedor VALUES('5', '16696595', 'BARCHUK GERARDO', 'BARRIO ANDRESITO', '3758-408155', '33', '1', '1');
INSERT INTO vendedor VALUES('4', '1111111', 'SEGOVIA LEO FABIO', 'SAN JAVIER', '3754-400329', '27', '1', '1');
INSERT INTO vendedor VALUES('6', '30430829', 'HELFENRITTER MATIAS', 'L.ALEM', '3754-458994', '6', '1', '1');
INSERT INTO vendedor VALUES('10', '92523447', 'WAPPLER DAVID', 'ITUZAINGO', '3786-458010', '36', '2', '1');
INSERT INTO vendedor VALUES('17', '31880573', 'ROLANDO BURAK', 'USHAI', '03758-15454255', '33', '1', '1');
INSERT INTO vendedor VALUES('15', '22727522', 'TORRES MARTIN', 'SAN VICENTE', '3755-500012', '8', '1', '1');
INSERT INTO vendedor VALUES('20', '11101091', 'DEPOSITO', 'RUTA 201 - KM 40', '3758-424181', '33', '1', '1');
INSERT INTO vendedor VALUES('12', '27414728', 'RAMIREZ PABLO MARTIN - LA CRUZ', 'BS.AS Y RIVADAVIA', '03772-15433320', '47', '2', '1');
INSERT INTO vendedor VALUES('11', '27414278', 'RAMIREZ PABLO MARTIN - ALVEAR', 'BS.AS Y RIVADAVIA', '03772-15433320', '25', '2', '1');
INSERT INTO vendedor VALUES('14', '14', 'RECALDE LUIS', 'XXX', '03758-15418500', '5', '1', '1');
INSERT INTO vendedor VALUES('21', '21', 'DEPOSITO', 'RTA.201 KM 2', '3758-424181', '33', '1', '1');
INSERT INTO vendedor VALUES('22', '22', 'DESCARGA', 'RUTA 201 KM 2', '03758-424181', '33', '1', '1');
INSERT INTO vendedor VALUES('19', '19', 'VENTA EN DEPOSITO', 'RTA.201 KM 2', '424181', '33', '1', '1');
INSERT INTO vendedor VALUES('18', '18', 'JOSE PEREIRA', 'XXX', '111111', '23', '1', '1');
INSERT INTO vendedor VALUES('13', '13', 'RECALDE LUIS', 'XXX', '3758-418500', '58', '2', '1');
UNLOCK TABLES;


--
-- Table structure for table `zona`
--

DROP TABLE IF EXISTS zona;
CREATE TABLE `zona` (
  `cod_zona` int(11) NOT NULL auto_increment,
  `cod_localidad` int(11) NOT NULL,
  `cod_prov` int(11) NOT NULL,
  `cod_pais` int(11) NOT NULL,
  `nombre` text NOT NULL,
  `porc_vta` float default NULL,
  `porc_transporte` float default NULL,
  PRIMARY KEY  (`cod_zona`,`cod_localidad`,`cod_prov`,`cod_pais`),
  KEY `Ref1713` (`cod_localidad`,`cod_pais`,`cod_prov`),
  KEY `Reflocalidad13` (`cod_localidad`,`cod_prov`,`cod_pais`)
) ENGINE=MyISAM AUTO_INCREMENT=67 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `zona`
--

LOCK TABLES zona WRITE;
INSERT INTO zona VALUES('5', '33', '1', '1', 'APOSTOLES', '1.25', '1.452');
INSERT INTO zona VALUES('66', '6', '1', '1', 'L.N. ALEM', '3', '3');
INSERT INTO zona VALUES('65', '23', '1', '1', 'OBERA', '2', '2');
INSERT INTO zona VALUES('64', '39', '1', '1', 'POSADAS', '1', '1');
UNLOCK TABLES;



-- Dump de la Base de Datos Completo.